import worker from './worker.mjs';

// Pages supplies static files through context.next rather than a Worker asset
// binding. Preserve rewrites performed by worker.fetch for /studio and /overlay.
export function onRequest(context) {
  const assets={fetch:request=>context.next(request)};
  return worker.fetch(context.request,{...context.env,ASSETS:assets});
}
