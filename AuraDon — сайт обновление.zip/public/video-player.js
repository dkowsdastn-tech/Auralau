const access = new URLSearchParams(location.search).get('access') || '';
const widget = document.querySelector('#video-widget');
const iframeHost = document.querySelector('#youtube-player');
const donorLabel = document.querySelector('#donor-label');
const overlay = document.querySelector('#player-overlay');
const status = document.querySelector('#player-status');
const hint = document.querySelector('#player-hint');
const startButton = document.querySelector('#enable-playback');

let player = null;
let playerReady = false;
let playerApiFailed = false;
let currentId = '';
let currentRequest = null;
let loadedId = '';
let lastFinished = '';
let lastSettings = '';
let finishPending = '';
let maxSeconds = 180;
let playStartedAt = 0;
let polling = false;

const api = (path, options = {}) => fetch(path, {cache: 'no-store', ...options}).then(async response => {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Error(data.error || 'Сервис видео временно недоступен');
  return data;
});

function setVisible(visible) { widget.hidden = !visible; }

function showOverlay(message = 'Браузерный источник остановил автозапуск звука. Нажмите кнопку один раз.') {
  if (!currentRequest) return;
  status.textContent = message;
  overlay.hidden = false;
}

function applySettings(settings = {}) {
  // Keep the embedded video at least 200 × 200 px as required by YouTube.
  const requestedWidth = Number(settings.widgetWidth);
  const width = requestedWidth === 520 ? 520 : 420;
  widget.style.setProperty('--widget-width', width + 'px');
  widget.classList.toggle('position-left', settings.position === 'left');
  widget.classList.toggle('position-right', settings.position !== 'left');
  maxSeconds = Math.max(15, Math.min(600, Number(settings.maxSeconds) || 180));
  try {
    if (player && Number.isFinite(Number(settings.volume))) player.setVolume(Math.max(0, Math.min(100, Number(settings.volume))));
  } catch {}
}

function setCurrent(item) {
  currentRequest = item || null;
  currentId = item?.id || '';
  loadedId = '';
  playStartedAt = 0;
  if (!item) {
    donorLabel.textContent = '';
    hint.textContent = '';
    overlay.hidden = true;
    setVisible(false);
    return;
  }
  const amount = Number(item.donation_amount || 0).toLocaleString('ru-RU');
  donorLabel.textContent = (item.requester_name || 'Аноним') + ' · ' + amount + ' ₸';
  hint.textContent = '';
  setVisible(true);
  if (playerApiFailed) showOverlay('Не удалось загрузить YouTube. Проверьте интернет в источнике браузера.');
  else if (!playerReady) showOverlay('Подключаем YouTube-плеер…');
  else overlay.hidden = true;
}

function loadCurrent() {
  if (!playerReady || !player || !currentRequest || currentId === lastFinished || loadedId === currentId) return;
  const id = currentId;
  loadedId = id;
  try {
    player.setVolume(Math.max(0, Math.min(100, Number(window.auraVideoSettings?.volume ?? 50))));
    player.loadVideoById({videoId: currentRequest.youtube_id, startSeconds: 0, endSeconds: maxSeconds});
    overlay.hidden = true;
  } catch {
    loadedId = '';
    showOverlay();
  }
}

async function completeId(id, outcome, attempt = 0) {
  try {
    await api('/api/cloud/video/complete?access=' + encodeURIComponent(access), {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({id, outcome})
    });
    if (currentId === id) setCurrent(null);
    if (finishPending === id) finishPending = '';
  } catch {
    if (currentId === id) hint.textContent = 'Связь восстанавливается…';
    window.setTimeout(() => completeId(id, outcome, attempt + 1), Math.min(10000, 1000 * (attempt + 1)));
  }
}

function finish(outcome = 'completed') {
  if (!currentRequest || finishPending === currentId) return;
  const id = currentId;
  lastFinished = id;
  finishPending = id;
  completeId(id, outcome);
}

function safePlay() {
  if (!playerReady || !player || !currentRequest) {
    showOverlay('Плеер ещё подключается.');
    return;
  }
  try {
    overlay.hidden = true;
    player.playVideo();
  } catch { showOverlay(); }
}

startButton.addEventListener('click', safePlay);

window.onYouTubeIframeAPIReady = () => {
  playerApiFailed = false;
  player = new YT.Player(iframeHost, {
    width: '100%', height: '100%',
    playerVars: {autoplay: 1, controls: 1, playsinline: 1, rel: 0, enablejsapi: 1, origin: location.origin},
    events: {
      onReady: event => {
        playerReady = true;
        try { event.target.setVolume(Math.max(0, Math.min(100, Number(window.auraVideoSettings?.volume ?? 50)))); } catch {}
        loadCurrent();
      },
      onStateChange: event => {
        if (event.data === YT.PlayerState.PLAYING) {
          playStartedAt = Date.now();
          overlay.hidden = true;
        } else if (event.data === YT.PlayerState.ENDED) finish('completed');
      },
      onError: () => finish('failed'),
      onAutoplayBlocked: () => showOverlay()
    }
  });
};

const youtubeApi = document.createElement('script');
youtubeApi.src = 'https://www.youtube.com/iframe_api';
youtubeApi.async = true;
youtubeApi.onerror = () => {
  playerApiFailed = true;
  if (currentRequest) showOverlay('Не удалось загрузить YouTube. Проверьте интернет в источнике браузера.');
};
document.head.append(youtubeApi);

async function poll() {
  if (!access) { setVisible(false); return; }
  if (polling) return;
  polling = true;
  try {
    const data = await api('/api/cloud/video/player?access=' + encodeURIComponent(access));
    const settings = data.settings || {};
    const signature = JSON.stringify(settings);
    if (signature !== lastSettings) {
      lastSettings = signature;
      window.auraVideoSettings = settings;
      applySettings(settings);
    }

    if (!settings.enabled || settings.panic || !data.current) {
      if (player && currentRequest) player.stopVideo();
      lastFinished = '';
      setCurrent(null);
    } else if (data.current.id === lastFinished) {
      hint.textContent = 'Переключаем ролик…';
    } else if (data.current.id !== currentId) {
      setCurrent(data.current);
      loadCurrent();
    }

    if (currentRequest && playerReady && playStartedAt && Date.now() - playStartedAt > maxSeconds * 1000) {
      let seconds = 0;
      try { seconds = Number(player.getCurrentTime()) || 0; } catch {}
      if (seconds >= maxSeconds - 1) finish('completed');
    }
  } catch (error) {
    if (currentRequest) hint.textContent = error.message || 'Связь с сервером временно потеряна.';
  } finally {
    polling = false;
    window.setTimeout(poll, 1200);
  }
}

poll();
