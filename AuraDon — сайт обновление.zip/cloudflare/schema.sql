CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  username_key TEXT NOT NULL UNIQUE,
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  recovery_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user_id ON sessions(user_id);
CREATE TABLE IF NOT EXISTS auth_attempts (
  key TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  count INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS entitlements (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  trial_end INTEGER NOT NULL DEFAULT 0,
  paid_end INTEGER NOT NULL DEFAULT 0,
  paid_tier TEXT NOT NULL DEFAULT 'pro' CHECK(paid_tier IN ('pro','ultimate'))
);
CREATE TABLE IF NOT EXISTS trial_claims (user_id TEXT PRIMARY KEY, claimed_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS admin_audit (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  action TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS device_pairs (
  code_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS devices (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL,
  relay_token TEXT,
  revoked_at INTEGER
);
CREATE INDEX IF NOT EXISTS devices_user_id ON devices(user_id);
CREATE UNIQUE INDEX IF NOT EXISTS devices_relay_token ON devices(relay_token) WHERE relay_token IS NOT NULL;
CREATE TABLE IF NOT EXISTS object_storage (
  key TEXT PRIMARY KEY,
  data BLOB NOT NULL
);
CREATE TABLE IF NOT EXISTS video_stream_settings (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)),
  volume INTEGER NOT NULL DEFAULT 50 CHECK(volume BETWEEN 0 AND 100),
  panic INTEGER NOT NULL DEFAULT 0 CHECK(panic IN (0,1)),
  min_amount INTEGER NOT NULL DEFAULT 500 CHECK(min_amount BETWEEN 100 AND 10000000),
  max_seconds INTEGER NOT NULL DEFAULT 180 CHECK(max_seconds BETWEEN 15 AND 600),
  position TEXT NOT NULL DEFAULT 'right' CHECK(position IN ('left','right')),
  widget_width INTEGER NOT NULL DEFAULT 420 CHECK(widget_width IN (320,420,520)),
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS video_requests (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  requester_name TEXT NOT NULL,
  youtube_id TEXT NOT NULL,
  message TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','queued','playing','completed','skipped','rejected','stopped','failed')),
  donation_amount REAL,
  donation_event_id TEXT UNIQUE,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS video_requests_queue ON video_requests(user_id,status,created_at);
