// Small deployment fallback when R2 is not enabled. Media is stored in the
// existing 512 KiB chunks; callers enforce upload limits and authorization.
export function d1Storage(db) {
  return {
    async put(key,value) {
      const bytes=typeof value==='string'?new TextEncoder().encode(value):new Uint8Array(value);
      await db.prepare('INSERT INTO object_storage (key,data) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET data=excluded.data').bind(key,bytes).run();
    },
    async get(key) {
      const row=await db.prepare('SELECT data FROM object_storage WHERE key = ?').bind(key).first();
      if(!row)return null;
      const bytes=new Uint8Array(row.data);
      return {text:async()=>new TextDecoder().decode(bytes),json:async()=>JSON.parse(new TextDecoder().decode(bytes)),arrayBuffer:async()=>bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)};
    }
  };
}
