import {createHash} from 'node:crypto';
import {TOP_STYLES} from '../public/top-catalog.js';
import {ALERT_GIFS} from '../public/alert-gifs.js';
import {entitlement} from './plans.mjs';

const hash = value => createHash('sha256').update(value).digest('hex');
const json = (body, status=200) => Response.json(body,{status,headers:{'Cache-Control':'no-store'}});

// These fields are deliberately limited until the complete cloud editor is ready.
export async function settingsHandler(req, db) {
  if (!db) return json({error:'Сервер аккаунтов не настроен'},503);
  const url = new URL(req.url);
  const token = (req.headers.get('cookie')||'').match(/(?:^|;\s*)auradon_cloud_session=([a-f0-9]{64})(?:;|$)/)?.[1];
  if (!token) return json({error:'Войдите в аккаунт'},401);
  const user = await db.prepare('SELECT user_id FROM sessions WHERE token_hash = ? AND expires_at > ?').bind(hash(token),Date.now()).first();
  if (!user) return json({error:'Войдите в аккаунт'},401);
  const key = 'user-settings/'+user.user_id;
  if (req.method === 'GET') {
    const row = await db.prepare('SELECT data FROM object_storage WHERE key = ?').bind(key).first();
    return json({settings:row?JSON.parse(new TextDecoder().decode(new Uint8Array(row.data))):{}});
  }
  if (req.method !== 'POST' || req.headers.get('origin') !== url.origin) return json({error:'Недопустимый запрос'},403);
  let body; try {const text=await req.text();if(text.length>4096)throw Error();body=JSON.parse(text);} catch {return json({error:'Неверные настройки'},400);}
  const entitlementRow=await db.prepare('SELECT trial_end,paid_end,paid_tier FROM entitlements WHERE user_id=?').bind(user.user_id).first();
  const plan=entitlement({trialEnd:entitlementRow?.trial_end,paidEnd:entitlementRow?.paid_end,paidTier:entitlementRow?.paid_tier});
  const goalName=String(body.goalName||'').trim(), goalTarget=Number(body.goalTarget), topCount=Number(body.topCount);
  if (!goalName || goalName.length>80 || !Number.isFinite(goalTarget) || goalTarget<1 || goalTarget>1000000000 || !Number.isInteger(topCount) || topCount<1 || topCount>10 || !/^#[a-f0-9]{6}$/i.test(body.goalAccent||'') || typeof body.tts!=='boolean') return json({error:'Проверьте название, сумму, цвет и количество мест'},400);
  if(plan==='free'&&(body.tts||body.ttsVoice))return json({error:'Озвучка донатов доступна на тарифах Pro и Ultimate'},403);
  const choices={theme:['aura','nova','glass','pixel'],bigTheme:['aura','nova','glass','pixel'],topStyle:TOP_STYLES.map(item=>item.id),goalStyle:['broadcast','tube','goldbar','icebar','rosebar','limebar','chrome','minimal','aurora','neon','battery','classic','tiktok','prism','sunset','mint'],bannerStyle:['aura','glass','rose','kaspi','midnight','gold','mint','sunset'],topLayout:['vertical','horizontal','ticker','rotate'],topMotion:['slide','float','none'],animation:['float','pulse','spin','none','heartbeat','wave'],enter:['bounce','fade','slide','zoom','glitch','burst'],goalPeriod:['all','day','month','session'],font:['Manrope','Oswald','Segoe UI','Georgia','Consolas'],soundPreset:['aura','coin','glass','arcade','spark','soft','pulse','victory']};
  if(body.topStyle!==undefined){const index=TOP_STYLES.findIndex(item=>item.id===body.topStyle),limit=plan==='free'?1:plan==='pro'?20:TOP_STYLES.length;if(index<0)return json({error:'Недопустимое оформление'},400);if(index>=limit)return json({error:'Этот стиль недоступен на вашем тарифе'},403);}
  if(plan==='free'&&body.bannerStyle!==undefined&&body.bannerStyle!=='aura')return json({error:'Этот баннер доступен на Pro и Ultimate'},403);
  const settings={goalName,goalTarget,topCount,goalAccent:body.goalAccent,tts:body.tts};
  if(body.alertGif!==undefined){const selected=body.alertGif;if(!['logo','custom'].includes(selected)&&!ALERT_GIFS.some(g=>g.id===selected))return json({error:'Выберите анимацию из коллекции'},400);const gif=ALERT_GIFS.find(g=>g.id===selected);if((selected==='custom'||gif)&&(plan==='free'||plan==='pro'&&gif?.tier==='ultimate'))return json({error:'Эта анимация недоступна на вашем тарифе'},403);if(selected==='custom'&&!body.alertMediaId)return json({error:'Выберите загруженное изображение'},400);settings.alertGif=selected;}
  if(body.ttsVoice!==undefined&&body.ttsVoice!==''){if(!['ru-RU-SvetlanaNeural','ru-RU-DmitryNeural','kk-KZ-AigulNeural','kk-KZ-DauletNeural','en-US-JennyNeural','en-US-GuyNeural'].includes(body.ttsVoice))return json({error:'Выберите доступный голос Edge TTS'},400);settings.ttsVoice=body.ttsVoice;}
  for(const [key,allowed] of Object.entries(choices)) if(body[key]!==undefined){if(!allowed.includes(body[key]))return json({error:'Недопустимое оформление'},400);settings[key]=body[key];}
  for(const key of ['bannerTitle','bannerNumber','bannerText','bannerRecipient']) if(body[key]!==undefined){if(typeof body[key]!=='string'||body[key].length>100)return json({error:'Текст баннера слишком длинный'},400);settings[key]=body[key].trim();}
  for(const key of ['titleTemplate','messageTemplate']) if(body[key]!==undefined){if(typeof body[key]!=='string'||body[key].length>300)return json({error:'Шаблон текста слишком длинный'},400);settings[key]=body[key];}
  if(body.alertMediaId){if(!/^[a-f0-9-]{36}$/.test(body.alertMediaId))return json({error:'Неверный файл'},400);const row=await db.prepare('SELECT data FROM object_storage WHERE key = ?').bind('user-media/'+user.user_id+'/'+body.alertMediaId+'/meta').first();if(!row)return json({error:'Файл не найден'},400);const meta=JSON.parse(new TextDecoder().decode(new Uint8Array(row.data)));if(!meta.type.startsWith('image/'))return json({error:'Для алерта нужен файл изображения'},400);settings.alertMediaId=body.alertMediaId;}
  for(const key of ['accent','textColor','topAccent']) if(body[key]!==undefined){if(!/^#[a-f0-9]{6}$/i.test(body[key]))return json({error:'Недопустимый цвет'},400);settings[key]=body[key];}
  for(const [key,min,max] of [['duration',1,30],['fontSize',12,100],['volume',0,100],['goalBaseline',0,1000000000],['mediaSize',50,320],['alertX',10,90],['alertY',15,85],['bigAmount',1,10000000]]) if(body[key]!==undefined){const value=Number(body[key]);if(!Number.isFinite(value)||value<min||value>max)return json({error:'Недопустимое значение'},400);settings[key]=value;}
  for(const key of ['sound','enabled','paused','ttsOnlyMessage']) if(body[key]!==undefined){if(typeof body[key]!=='boolean')return json({error:'Недопустимый переключатель'},400);settings[key]=body[key];}
  await db.prepare('INSERT INTO object_storage (key,data) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET data=excluded.data').bind(key,new TextEncoder().encode(JSON.stringify(settings))).run();
  return json({settings});
}
