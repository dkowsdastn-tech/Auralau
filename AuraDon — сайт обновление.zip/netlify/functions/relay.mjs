import{getStore}from'@netlify/blobs';import{relayHandler}from'../relay-handler.mjs';
export default req=>relayHandler(req,getStore({name:'auradon-overlays-v1',consistency:'strong'}));
