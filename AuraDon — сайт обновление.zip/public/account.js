import {TOP_STYLES} from '/top-catalog.js';
import {renderTop} from '/widgets.js';
import {defaults} from '/shared.js';
import {ALERT_GIFS} from '/alert-gifs.js';
const $ = s => document.querySelector(s);
let mode = 'login';
const show = id => {for (const name of ['auth','logged','recovery']) $('#'+name).classList.toggle('hidden', name !== id);};
async function me() {
  try {
    const r = await fetch('/api/cloud/auth/me', {cache:'no-store'});
    if (r.ok) {const data=await r.json();$('#username').textContent=data.user.username;$('#current-plan').textContent=({free:'Free',pro:'Pro',ultimate:'Ultimate'})[data.plan]||'Free';renderLinks(data.overlayToken);renderVideo(data.user.username,data.overlayToken,data.plan||'free');show('logged');await loadSettings();renderAccess(data.plan||'free');applySection();return;}
  } catch {}
  show('auth');
}
document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click', () => {
  mode = button.dataset.mode;
  document.querySelectorAll('[data-mode]').forEach(item => item.classList.toggle('active', item === button));
  $('#recover-label').classList.toggle('hidden', mode !== 'recover');
  $('[name=password]').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  $('#error').textContent = '';
}));
$('form').addEventListener('submit', async event => {
  event.preventDefault();
  const button = $('form button[type=submit]'); button.disabled = true; $('#error').textContent = '';
  try {
    const r = await fetch('/api/cloud/auth/'+mode, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(event.currentTarget)))});
    const result = await r.json();
    if (!r.ok) throw Error(result.error || 'Не удалось выполнить запрос');
    if (result.recovery) {$('#recovery-code').textContent=result.recovery; show('recovery');} else await me();
  } catch (error) {$('#error').textContent=error.message || 'Нет соединения с сервером';}
  finally {button.disabled=false;}
});
$('#continue').onclick=me;
$('#logout').onclick=async()=>{await fetch('/api/cloud/auth/logout',{method:'POST'}); await me();};
const pairButton=document.createElement('button');
pairButton.type='button'; pairButton.textContent='Код подключения программы';
const pairOutput=document.createElement('p'); pairOutput.setAttribute('role','status');
$('#logged').append(pairButton,pairOutput);
const pricing=document.createElement('section');
pricing.id='plans';
pricing.innerHTML='<h2>Тариф и стоимость</h2><p>Текущий тариф: <strong id="current-plan">Free</strong>. Без автоматического продления.</p><p>Pro — от 449 ₸ за 7 дней; Ultimate — от 682 ₸ за 7 дней. За 60 дней: Pro — 2 990 ₸, Ultimate — 4 990 ₸. Первые 333 пользователя получают Pro на 7 дней.</p><form id="quote-form"><label>Тариф<select name="tier"><option value="pro">Pro</option><option value="ultimate">Ultimate</option></select></label><label>Срок, дней<input name="days" type="number" min="7" max="3660" value="60" required></label><label><input name="intro" type="checkbox"> Первая покупка на 30 дней</label><label>Промокод<input name="promo" autocomplete="off" maxlength="100" placeholder="Если вы получили промокод"></label><p id="long-offer" class="hidden">Скидка 20% на срок от 180 до 730 дней. Напишите нам в Telegram, чтобы узнать о промокоде.</p><button type="submit">Рассчитать стоимость</button><p id="quote-result" role="status"></p></form><p><a href="https://t.me/+Cql-lUdmVzs2YTJi" target="_blank" rel="noopener">Написать о покупке в Telegram ↗</a></p><p>Первая покупка: Pro — 990 ₸ или Ultimate — 2 490 ₸ на 30 дней. Право на акцию подтверждается при покупке.</p>';
$('#logged').append(pricing);
const offer=document.createElement('div');offer.className='pricing-offer';offer.innerHTML='Первая покупка · 30 дней <strong>Pro за 990 ₸</strong>';pricing.prepend(offer);
const editor=document.createElement('section');editor.id='editor-panel';
editor.innerHTML='<h2>Настройки виджетов</h2><p>Настройки сохраняются в аккаунте и применяются к подключённым виджетам.</p><form id="widget-settings"><label>Название цели<input name="goalName" maxlength="80" required value="На мечту"></label><label>Сумма цели, ₸<input name="goalTarget" type="number" min="1" max="1000000000" required value="10000"></label><label>Количество мест в топе<input name="topCount" type="number" min="1" max="10" required value="5"></label><label>Цвет цели<input name="goalAccent" type="color" value="#ffcf26"></label><label><input name="tts" type="checkbox"> Включить озвучку донатов</label><button type="submit">Сохранить настройки</button><p role="status"></p></form>';
$('#logged').append(editor);
const editorForm=editor.querySelector('form');
editorForm.id='widget-settings';
const addSelect=(name,label,options)=>{const wrapper=document.createElement('label');wrapper.textContent=label;const select=document.createElement('select');select.name=name;for(const [value,title] of options){const option=document.createElement('option');option.value=value;option.textContent=title;select.append(option);}wrapper.append(select);editorForm.insertBefore(wrapper,editorForm.querySelector('button[type=submit]'));};
const addInput=(name,label,type,value,min,max)=>{const wrapper=document.createElement('label');wrapper.textContent=label;const input=document.createElement('input');input.name=name;input.type=type;input.value=value;if(min!==undefined)input.min=min;if(max!==undefined)input.max=max;wrapper.append(input);editorForm.insertBefore(wrapper,editorForm.querySelector('button[type=submit]'));};
addSelect('theme','Тема алерта',[['aura','AuraDon']]);
addSelect('alertGif','Анимация доната',[['logo','Логотип AuraDon · Free'],['custom','Свой файл · Pro'],...ALERT_GIFS.map(g=>[g.id,g.name+' · '+g.tier.toUpperCase()])]);
const gifGallery=document.createElement('div');gifGallery.className='gif-gallery';editorForm.elements.alertGif.closest('label').after(gifGallery);
function renderAccess(plan){
 const gifSelect=editorForm.elements.alertGif;
 const topLimit=plan==='ultimate'?TOP_STYLES.length:plan==='pro'?20:1;
 for(const option of editorForm.elements.bannerStyle.options)option.disabled=plan==='free'&&option.value!=='aura';
 if(plan==='free')editorForm.elements.bannerStyle.value='aura';
 editorForm.elements.tts.disabled=plan==='free';
 editorForm.elements.ttsVoice.disabled=plan==='free';
 editorForm.elements.ttsOnlyMessage.disabled=plan==='free';
 if(plan==='free'){editorForm.elements.tts.checked=false;editorForm.elements.ttsVoice.value='';}
 editorForm.querySelector('[data-tts-tier-note]')?.remove();
 if(plan==='free'){const note=document.createElement('p');note.dataset.ttsTierNote='';note.className='tier-note';note.textContent='Озвучка донатов доступна на Pro и Ultimate.';editorForm.elements.tts.closest('label').after(note);}
 for(const option of gifSelect.options){const item=ALERT_GIFS.find(g=>g.id===option.value);option.disabled=option.value==='custom'&&plan==='free'||!!item&&(plan==='free'||plan==='pro'&&item.tier==='ultimate');}
 if(gifSelect.selectedOptions[0]?.disabled)gifSelect.value='logo';
 for(const [i,option] of [...editorForm.elements.topStyle.options].entries())option.disabled=i>=topLimit;
 if(editorForm.elements.topStyle.selectedOptions[0]?.disabled)editorForm.elements.topStyle.selectedIndex=0;
 gifGallery.replaceChildren();
 for(const item of [{id:'logo',file:'auradon-pixel-a.png',name:'AuraDon',tier:'free'},...ALERT_GIFS]){
  const locked=item.tier!=='free'&&(plan==='free'||plan==='pro'&&item.tier==='ultimate');
  const card=document.createElement('article');card.className='gif-card'+(locked?' locked':'');
  const img=document.createElement('img');img.src='/assets/'+item.file;img.alt='';img.loading='lazy';
  const title=document.createElement('strong');title.textContent=item.name;
  const badge=document.createElement(locked?'a':'button');
  if(locked){badge.href='https://t.me/+Cql-lUdmVzs2YTJi';badge.target='_blank';badge.rel='noopener';badge.textContent='🔒 Купить '+(item.tier==='ultimate'?'Ultimate':'Pro');}
  else{badge.type='button';badge.textContent='Выбрать';badge.onclick=()=>{gifSelect.value=item.id;editorForm.querySelector('p[role=status]').textContent='Выбрано. Нажмите «Сохранить настройки».';};}
  card.append(img,title,badge);gifGallery.append(card);
 }
 for(const [i,card] of [...grid.children].entries()) {const locked=i>=topLimit;card.classList.toggle('locked-design',locked);card.onclick=locked?()=>window.open('https://t.me/+Cql-lUdmVzs2YTJi','_blank','noopener'):()=>{const style=TOP_STYLES[i];editorForm.elements.topStyle.value=style.id;editorForm.elements.topAccent.value=style.accent;selectGroup('top');location.hash='widget-settings';editorForm.scrollIntoView({behavior:'smooth'});};card.setAttribute('aria-label',locked?TOP_STYLES[i].label+' — доступно по подписке':TOP_STYLES[i].label);}
}
addSelect('ttsVoice','Голос озвучки',[
 ['ru-RU-SvetlanaNeural','Svetlana · Русский · женский'],
 ['ru-RU-DmitryNeural','Dmitry · Русский · мужской'],
 ['kk-KZ-AigulNeural','Aigul · Қазақша · әйел'],
 ['kk-KZ-DauletNeural','Daulet · Қазақша · ер'],
 ['en-US-JennyNeural','Jenny · English · female'],
 ['en-US-GuyNeural','Guy · English · male']
]);
const onlyMessage=document.createElement('label');onlyMessage.innerHTML='<input name="ttsOnlyMessage" type="checkbox"> Читать только сообщение';editorForm.insertBefore(onlyMessage,editorForm.querySelector('button[type=submit]'));
const voiceNote=document.createElement('small');voiceNote.className='voice-note';voiceNote.textContent='Edge TTS · 6 онлайн-голосов. Не нужны ключи или отдельная регистрация; для озвучки нужен интернет. Доступно на Pro и Ultimate.';editorForm.elements.ttsVoice.closest('label').append(voiceNote);
const mediaLabel=document.createElement('label');mediaLabel.textContent='GIF или изображение алерта (медиатека до 20 МБ)';const mediaInput=document.createElement('input');mediaInput.type='file';mediaInput.accept='image/gif,image/png,image/jpeg,image/webp';const mediaStatus=document.createElement('span');mediaStatus.setAttribute('role','status');const mediaId=document.createElement('input');mediaId.type='hidden';mediaId.name='alertMediaId';mediaLabel.append(mediaInput,mediaStatus,mediaId);editorForm.insertBefore(mediaLabel,editorForm.querySelector('button[type=submit]'));const removeMedia=document.createElement('button');removeMedia.type='button';removeMedia.textContent='Удалить выбранный файл';mediaLabel.append(removeMedia);removeMedia.onclick=async()=>{if(!mediaId.value){mediaStatus.textContent='Файл не выбран';return;}if(!confirm('Удалить выбранный файл из медиатеки?'))return;removeMedia.disabled=true;try{const r=await fetch('/api/cloud/media?id='+encodeURIComponent(mediaId.value),{method:'DELETE'}),data=await r.json();if(!r.ok)throw Error(data.error);mediaId.value='';mediaInput.value='';mediaStatus.textContent='Файл удалён.';await refreshMedia();}catch(e){mediaStatus.textContent=e.message||'Ошибка удаления';}finally{removeMedia.disabled=false;}};mediaInput.onchange=async()=>{const file=mediaInput.files[0];if(!file)return;if(file.size>20*1024*1024){mediaStatus.textContent='Файл больше 20 МБ';return;}mediaStatus.textContent='Загружаем…';try{const r=await fetch('/api/cloud/media',{method:'POST',headers:{'Content-Type':file.type},body:file}),data=await r.json();if(!r.ok)throw Error(data.error);mediaId.value=data.id;mediaStatus.textContent='Загружено. Нажми «Сохранить настройки».';await refreshMedia();}catch(e){mediaStatus.textContent=e.message||'Ошибка загрузки';}};
const mediaList=document.createElement('select');mediaList.setAttribute('aria-label','Файлы медиатеки');mediaLabel.insertBefore(mediaList,removeMedia);async function refreshMedia(){const r=await fetch('/api/cloud/media?list=1');if(!r.ok)return;const data=await r.json(),current=mediaId.value;mediaList.replaceChildren(new Option('Выбрать загруженный файл',''));for(const [i,file] of data.files.entries())mediaList.add(new Option((i+1)+'. '+file.type+' · '+Math.ceil(file.size/1024)+' КБ',file.id));mediaList.value=current;}mediaList.onchange=()=>{mediaId.value=mediaList.value;mediaStatus.textContent='Нажми «Сохранить настройки».';};
addSelect('topStyle','Оформление топа',TOP_STYLES.map(x=>[x.id,x.label+' · '+x.tier.toUpperCase()]));
const gallery=document.createElement('section');gallery.id='designs';gallery.innerHTML='<h2>Дизайны для твоего эфира</h2><p>Выбери стиль топа, затем сохрани настройки виджетов.</p><div class="design-grid"></div>';const grid=gallery.querySelector('.design-grid');gallery.insertAdjacentHTML('beforeend','<div class="gallery-pages"><button type="button" data-page-prev>← Назад</button><span aria-live="polite"></span><button type="button" data-page-next>Вперёд →</button></div>');for(const style of TOP_STYLES){const button=document.createElement('button');button.type='button';button.className='design-card';button.innerHTML='<div class="design-preview">'+renderTop([{name:'Alikhan',kind:'donation',amount:216000},{name:'Amina',kind:'donation',amount:202000},{name:'Nursultan',kind:'donation',amount:199860}],{...defaults,topStyle:style.id,topAccent:style.accent,topCount:3,topMotion:'float'},'Топ дня')+'</div><strong></strong><small></small>';button.querySelector(':scope > strong').textContent=style.label;button.querySelector(':scope > small').textContent=style.tier.toUpperCase();button.onclick=()=>{editorForm.elements.topStyle.value=style.id;editorForm.elements.topAccent.value=style.accent;selectGroup('top');location.hash='widget-settings';editorForm.scrollIntoView({behavior:'smooth'});};grid.append(button);}$('#logged').insertBefore(gallery,editor);let galleryPage=0;const showGalleryPage=()=>{const cards=[...grid.children],pages=Math.ceil(cards.length/6);cards.forEach((card,i)=>card.hidden=Math.floor(i/6)!==galleryPage);gallery.querySelector('.gallery-pages span').textContent=(galleryPage+1)+' / '+pages;gallery.querySelector('[data-page-prev]').disabled=galleryPage===0;gallery.querySelector('[data-page-next]').disabled=galleryPage>=pages-1;};gallery.querySelector('[data-page-prev]').onclick=()=>{galleryPage--;showGalleryPage()};gallery.querySelector('[data-page-next]').onclick=()=>{galleryPage++;showGalleryPage()};showGalleryPage();
addSelect('goalStyle','Оформление цели',[['broadcast','Эфир'],['tube','Неоновая капсула'],['goldbar','Золотая полоса'],['icebar','Лёд'],['rosebar','Розовый'],['limebar','Лайм'],['chrome','Хром'],['minimal','Минимум']]);
addSelect('bannerStyle','Оформление баннера Kaspi',[['aura','Aura · Free'],['glass','Prism · Pro'],['kaspi','Kaspi · Pro'],['rose','Rose · Pro'],['midnight','Midnight · Pro'],['gold','Gold · Pro'],['mint','Mint · Pro'],['sunset','Sunset · Pro']]);
addInput('bannerTitle','Заголовок баннера','text','Поддержать эфир');addInput('bannerNumber','Номер для перевода','text','');addInput('bannerRecipient','Имя получателя','text','');addInput('bannerText','Дополнительный текст','text','');
addSelect('topLayout','Расположение топа',[['vertical','Вертикально'],['horizontal','Горизонтально'],['ticker','Бегущая строка'],['rotate','По очереди']]);
addSelect('topMotion','Анимация топа',[['slide','Появление'],['float','Парение'],['none','Без движения']]);
addSelect('font','Шрифт алерта',[['Manrope','Manrope'],['Oswald','Oswald'],['Segoe UI','Segoe UI'],['Georgia','Georgia'],['Consolas','Consolas']]);
addInput('accent','Цвет алерта','color','#9278ee');addInput('textColor','Цвет текста','color','#302a46');addInput('topAccent','Цвет топа','color','#ffd12b');
addInput('duration','Время показа, сек.','number','6','1','30');addInput('fontSize','Размер текста','number','32','12','100');addInput('volume','Громкость, %','number','35','0','100');addInput('goalBaseline','Уже собрано, ₸','number','0','0','1000000000');
addInput('titleTemplate','Заголовок: {name} и {amount}','text','{name} · {amount}');addInput('messageTemplate','Текст сообщения: {message}','text','{message}');
addSelect('animation','Движение алерта',[['float','Парение'],['pulse','Пульсация'],['spin','Вращение'],['heartbeat','Сердцебиение'],['wave','Волна'],['none','Без движения']]);
addSelect('enter','Появление алерта',[['bounce','Пружина'],['fade','Плавно'],['slide','Снизу'],['zoom','Приближение'],['glitch','Глитч'],['burst','Искры']]);
addSelect('soundPreset','Звук доната',[['aura','Aura'],['coin','Монеты'],['glass','Хрусталь'],['arcade','Аркада'],['spark','Искра'],['soft','Мягкий'],['pulse','Импульс'],['victory','Победа']]);
addSelect('goalPeriod','Какие донаты учитывать в цели',[['all','Все'],['day','За день'],['month','За месяц'],['session','За эфир']]);
addInput('mediaSize','Размер GIF, px','number','150','50','320');addInput('alertX','Положение по горизонтали, %','number','50','10','90');addInput('alertY','Положение по вертикали, %','number','50','15','85');
const soundLabel=document.createElement('label'),soundInput=document.createElement('input');soundInput.type='checkbox';soundInput.name='sound';soundInput.checked=true;soundLabel.append(soundInput,document.createTextNode(' Звук уведомления'));editorForm.insertBefore(soundLabel,editorForm.querySelector('button[type=submit]'));
const editorStyles=document.createElement('style');editorStyles.textContent='#widget-settings input[type=checkbox]{display:inline-block;width:auto;margin:0 8px 0 0}#widget-settings input[type=color]{width:80px;height:44px;padding:4px}#widget-settings select{display:block;width:100%;margin-top:8px;padding:13px;border:1px solid #d7cbe7;border-radius:12px;background:white;color:#29213d;font:inherit}';document.head.append(editorStyles);
async function loadSettings(){const form=editor.querySelector('form');try{const r=await fetch('/api/cloud/settings',{cache:'no-store'});if(!r.ok)throw Error();const {settings}=await r.json();for(const [key,value] of Object.entries(settings)){const field=form.elements[key];if(!field)continue;if(field.type==='checkbox')field.checked=!!value;else field.value=value;}await refreshMedia();}catch{form.querySelector('p[role=status]').textContent='Не удалось загрузить настройки';}}
editor.querySelector('form').onsubmit=async event=>{event.preventDefault();const form=event.currentTarget,status=form.querySelector('p[role=status]'),button=form.querySelector('button[type=submit]');button.disabled=true;try{const body=Object.fromEntries(new FormData(form));body.tts=form.elements.tts.checked;body.ttsOnlyMessage=form.elements.ttsOnlyMessage.checked;body.sound=form.elements.sound.checked;const r=await fetch('/api/cloud/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),data=await r.json();if(!r.ok)throw Error(data.error);status.textContent='Сохранено. Настройки применятся к подключённым виджетам.';}catch(e){status.textContent=e.message||'Нет соединения с сервером';}finally{button.disabled=false;}};
const quoteStyles=document.createElement('style');quoteStyles.textContent='#quote-form input[type=checkbox]{display:inline-block;width:auto;margin:0 8px 0 0}#quote-form select{display:block;width:100%;margin-top:8px;padding:13px;border:1px solid #d7cbe7;border-radius:12px;background:#fff;color:#29213d}';document.head.append(quoteStyles);
const quoteForm=pricing.querySelector('form');
const updateQuote=()=>{const intro=quoteForm.elements.intro.checked,days=quoteForm.elements.days,promo=quoteForm.elements.promo;if(intro){days.value='30';promo.value='';}days.readOnly=intro;promo.disabled=intro;pricing.querySelector('#long-offer').classList.toggle('hidden',intro||Number(days.value)<180||Number(days.value)>730);};
quoteForm.addEventListener('change',updateQuote);quoteForm.addEventListener('input',updateQuote);
quoteForm.addEventListener('submit',async event=>{event.preventDefault();const button=quoteForm.querySelector('button'),result=pricing.querySelector('#quote-result');button.disabled=true;result.textContent='';try{const form=new FormData(quoteForm);const r=await fetch('/api/cloud/quote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tier:form.get('tier'),days:form.get('days'),intro:quoteForm.elements.intro.checked,promo:form.get('promo')||''})}),data=await r.json();if(!r.ok)throw Error(data.error);result.textContent='Расчёт: '+new Intl.NumberFormat('ru-KZ').format(data.quote.amount)+' ₸ за '+data.quote.days+' дней'+(data.quote.discount?' (скидка 20%)':'')+'. Окончательная стоимость подтверждается при покупке.';}catch(error){result.textContent=error.message || 'Нет соединения с сервером';}finally{button.disabled=false;}});
const links=document.createElement('div');$('#logged').append(links);
links.id='links';
function renderLinks(token) {
  links.replaceChildren();
  if (!token) {const p=document.createElement('p');p.textContent='Подключите программу, чтобы получить персональные ссылки виджетов.';const refresh=document.createElement('button');refresh.type='button';refresh.textContent='Обновить ссылки после подключения';refresh.onclick=me;links.append(p,refresh);return;}
  const title=document.createElement('h2');title.textContent='Ваши виджеты';links.append(title);
  for(const [label,widget,width,height] of [['Алерты','alerts',640,520],['Топ дня','top-day',600,266],['Топ месяца','top-month',600,266],['Цель','goal',720,84],['Баннер','banner',640,240]]) {
    const url=new URL('/overlay',location.origin);url.searchParams.set('widget',widget);url.searchParams.set('access',token);url.searchParams.set('relay','1');url.searchParams.set('fit','1');
    url.searchParams.set('width',width);url.searchParams.set('height',height);
    const row=document.createElement('p'),button=document.createElement('button');button.textContent='Скопировать: '+label;
    button.onclick=async()=>{try{await navigator.clipboard.writeText(url.href);button.textContent='Скопировано: '+label;}catch{const input=document.createElement('input');input.value=url.href;input.readOnly=true;row.append(input);input.select();}};
    row.append(button);links.append(row);
  }
}
function renderVideo(username,token,plan){
 let section=document.querySelector('#video-queue');if(!section){section=document.createElement('section');section.id='video-queue';links.after(section);}
 section.replaceChildren();
 const heading=document.createElement('h2');heading.textContent='Заказ видео';section.append(heading);
 if(plan!=='ultimate'){
  const lock=document.createElement('div');lock.className='video-locked';lock.innerHTML='<span aria-hidden="true">🔒</span><strong>YouTube Media Player · Ultimate</strong><p>Автоочередь YouTube-ссылок из комментариев Kaspi, компактный плеер, настройка эфира и кнопка мгновенной остановки.</p><a href="https://t.me/+Cql-lUdmVzs2YTJi" target="_blank" rel="noopener">Узнать про Ultimate ↗</a>';section.append(lock);return;
 }
 section.insertAdjacentHTML('beforeend','<div class="video-how"><strong>Ссылка на YouTube — в комментарии к переводу Kaspi</strong><ol><li>Зритель отправляет перевод Kaspi и вставляет ссылку YouTube прямо в комментарий.</li><li>Подключённый AuraDon.exe получает уведомление «Связи с телефоном» и проверяет входящий платёж.</li><li>Если плеер включён и сумма достигает порога, видео автоматически становится в очередь и появляется в небольшом окне внизу сцены.</li></ol><p>Зрителю не нужна отдельная форма. Добавь скопированную ссылку плеера как источник «Ссылка» в TikTok LIVE Studio или Browser Source в OBS. Фон источника прозрачный.</p></div><p class="video-policy">Видео проигрывается официальным YouTube-плеером. Некоторые ролики запрещают встраивание, а браузер источника может потребовать один раз нажать «Включить звук» из-за политики автозапуска.</p>');
 const feedback=document.createElement('p');feedback.className='video-feedback';feedback.setAttribute('role','status');feedback.setAttribute('aria-live','polite');
 const playerLink=new URL('/video-player.html',location.origin);if(token)playerLink.searchParams.set('access',token);
 const playerButton=document.createElement('button');playerButton.type='button';playerButton.className='video-copy-link';playerButton.textContent=token?'Скопировать ссылку для TikTok / OBS':'Сначала подключи AuraDon.exe';playerButton.disabled=!token;playerButton.onclick=()=>copyButton(playerLink.href,playerButton,'Ссылка скопирована',feedback);
 const linkRow=document.createElement('div');linkRow.className='video-links';linkRow.append(playerButton);section.append(linkRow);
 if(!token){const hint=document.createElement('p');hint.className='video-policy';hint.textContent='Подключи приложение к этому аккаунту один раз. После подключения здесь появится постоянная ссылка источника.';section.append(hint);}
 const settingsForm=document.createElement('form');settingsForm.className='video-settings';settingsForm.innerHTML='<label class="video-enable"><input name="enabled" type="checkbox"> Включить YouTube-плеер</label><label>Минимальный донат, ₸<input name="minAmount" type="number" min="100" max="10000000" step="100" value="500"></label><label>Громкость <output>50%</output><input name="volume" type="range" min="0" max="100" value="50"></label><label>Максимум на один ролик<select name="maxSeconds"><option value="60">1 минута</option><option value="120">2 минуты</option><option value="180" selected>3 минуты</option><option value="300">5 минут</option><option value="600">10 минут</option></select></label><label>Угол сцены<select name="position"><option value="right">Снизу справа</option><option value="left">Снизу слева</option></select></label><label>Ширина плеера<select name="widgetWidth"><option value="420" selected>Средний · 420 px</option><option value="520">Крупный · 520 px</option></select></label><button type="submit">Сохранить настройки</button><p role="status" aria-live="polite"></p>';
 section.append(settingsForm);
 const controls=document.createElement('div');controls.className='video-controls';
 for(const [action,label,extra] of [['play','Запустить очередь',''],['skip','Пропустить текущее видео',''],['panic','СТОП · PANIC','panic']]){const button=document.createElement('button');button.type='button';button.dataset.action=action;button.className=extra;button.textContent=label;button.onclick=()=>manageVideo(action,button,null,feedback);controls.append(button);}
 section.append(controls,feedback);
 const listHeading=document.createElement('h3');listHeading.textContent='Очередь и история';section.append(listHeading);
 const queue=document.createElement('div');queue.className='video-queue-list';queue.setAttribute('aria-live','polite');queue.textContent='Загружаем очередь…';section.append(queue);
 const statusLabels={queued:'В очереди',playing:'Сейчас в эфире',completed:'Завершено',skipped:'Пропущено',stopped:'Остановлено',failed:'YouTube недоступен'};
 async function reloadQueue(){try{const r=await fetch('/api/cloud/video/queue',{cache:'no-store'}),data=await r.json();if(!r.ok)throw Error(data.error||'Не удалось загрузить очередь');settingsForm.elements.enabled.checked=data.settings.enabled===1;settingsForm.elements.volume.value=data.settings.volume;settingsForm.querySelector('output').value=data.settings.volume+'%';settingsForm.elements.minAmount.value=data.settings.min_amount??500;settingsForm.elements.maxSeconds.value=String(data.settings.max_seconds??180);settingsForm.elements.position.value=data.settings.position||'right';settingsForm.elements.widgetWidth.value=Number(data.settings.widget_width)===520?'520':'420';queue.replaceChildren();if(!data.requests.length){queue.textContent='Пока нет ссылок из Kaspi-уведомлений.';return;}for(const item of data.requests){const card=document.createElement('article');card.className='video-request-item status-'+item.status;const main=document.createElement('div'),name=document.createElement('strong'),state=document.createElement('span'),link=document.createElement('a'),message=document.createElement('p'),amount=document.createElement('b');name.textContent=item.requester_name;state.className='video-state';state.textContent=statusLabels[item.status]||item.status;amount.className='video-amount';amount.textContent=Number(item.donation_amount||0).toLocaleString('ru-RU')+' ₸';link.href='https://www.youtube.com/watch?v='+encodeURIComponent(item.youtube_id);link.target='_blank';link.rel='noopener';link.textContent='Проверить ролик ↗';message.textContent=item.message||'Комментарий без текста';main.append(name,amount,state,link,message);card.append(main);queue.append(card);}}catch(error){queue.textContent=error.message||'Не удалось загрузить очередь';}}
 settingsForm.elements.volume.addEventListener('input',()=>settingsForm.querySelector('output').value=settingsForm.elements.volume.value+'%');
 settingsForm.addEventListener('submit',async event=>{event.preventDefault();const button=settingsForm.querySelector('button[type=submit]'),status=settingsForm.querySelector('[role=status]');button.disabled=true;try{await postVideo({action:'settings',enabled:settingsForm.elements.enabled.checked,volume:Number(settingsForm.elements.volume.value),minAmount:Number(settingsForm.elements.minAmount.value),maxSeconds:Number(settingsForm.elements.maxSeconds.value),position:settingsForm.elements.position.value,widgetWidth:Number(settingsForm.elements.widgetWidth.value)});status.textContent='Настройки сохранены.';await reloadQueue();}catch(e){status.textContent=e.message||'Ошибка сохранения';}finally{button.disabled=false;}});
 reloadQueue();const timer=setInterval(()=>{if(!section.isConnected){clearInterval(timer);return;}reloadQueue();},5000);
}
async function copyButton(value,button,success,statusElement){button.dataset.original=button.dataset.original||button.textContent;try{await navigator.clipboard.writeText(value);button.textContent=success;setTimeout(()=>button.textContent=button.dataset.original,1800);}catch{const input=document.createElement('input');input.value=value;input.readOnly=true;input.setAttribute('aria-label','Ссылка для копирования');button.after(input);input.focus();input.select();if(statusElement)statusElement.textContent='Буфер обмена недоступен — ссылка выделена для копирования.';}}
async function postVideo(body){const r=await fetch('/api/cloud/video/manage',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),data=await r.json();if(!r.ok)throw Error(data.error||'Не удалось выполнить действие');return data;}
async function manageVideo(action,button,id,feedbackElement){button.disabled=true;try{await postVideo({action,...(id?{id}:{})});feedbackElement.textContent=action==='panic'?'Видео остановлено. Чтобы возобновить, запусти очередь.':action==='play'?'Очередь запущена.':action==='skip'?'Текущее видео пропущено.':'Готово.';button.textContent=action==='panic'?'Остановлено':'Готово';setTimeout(()=>{button.disabled=false;button.textContent=action==='play'?'Запустить очередь':action==='skip'?'Пропустить текущее видео':action==='panic'?'СТОП · PANIC':button.textContent;},1600);return true;}catch(error){button.disabled=false;button.title=error.message;feedbackElement.textContent=error.message||'Не удалось выполнить действие.';throw error;}}
pairButton.onclick=async()=>{
  pairButton.disabled=true; pairOutput.textContent='Создаём код…';
  try {
    const r=await fetch('/api/cloud/device/create',{method:'POST'}), data=await r.json();
    if(!r.ok)throw Error(data.error || 'Не удалось создать код');
    pairOutput.replaceChildren(document.createTextNode('Код действует 10 минут и используется один раз. Вставьте его в AuraDon → Подключения.'));
    const code=document.createElement('code');code.textContent=data.code;pairOutput.append(code);
    const copy=document.createElement('button');copy.type='button';copy.textContent='Скопировать код';copy.onclick=async()=>{try{await navigator.clipboard.writeText(data.code);copy.textContent='Код скопирован';}catch{const selection=window.getSelection();const range=document.createRange();range.selectNodeContents(code);selection.removeAllRanges();selection.addRange(range);copy.textContent='Скопируйте выделенный код';}};pairOutput.append(copy);
  } catch(error) {pairOutput.textContent=error.message || 'Нет соединения с сервером';}
  finally {pairButton.disabled=false;}
};


const categories=[['alerts','Алерт и GIF'],['sound','Звук и голос'],['top','Топы'],['goal','Цель'],['banner','Баннер']];
const editorTabs=document.createElement('div');editorTabs.className='editor-tabs';editorTabs.setAttribute('role','tablist');const groups={};
for(const [id,label] of categories){const button=document.createElement('button');button.type='button';button.textContent=label;button.setAttribute('role','tab');button.dataset.group=id;editorTabs.append(button);const group=document.createElement('div');group.dataset.editorGroup=id;groups[id]=group;}
const selectGroup=id=>{for(const [name] of categories){groups[name].hidden=name!==id;const button=editorTabs.querySelector('[data-group="'+name+'"]');button.setAttribute('aria-selected',String(name===id));button.classList.toggle('active',name===id);}};
editorTabs.addEventListener('click',event=>{const button=event.target.closest('button[data-group]');if(button)selectGroup(button.dataset.group);});
for(const label of [...editorForm.children].filter(el=>el.tagName==='LABEL')){const name=label.querySelector('[name]')?.name||'';let group='alerts';if(/^tts|^(sound|soundPreset|volume)$/.test(name))group='sound';else if(/^top/.test(name))group='top';else if(/^goal/.test(name))group='goal';else if(/^banner/.test(name))group='banner';groups[group].append(label);}
groups.alerts.append(gifGallery,mediaLabel);const submit=editorForm.querySelector('button[type=submit]');editorForm.prepend(editorTabs,...Object.values(groups));selectGroup('alerts');

const instructions=document.createElement('section');instructions.id='instructions';instructions.innerHTML='<h2>Как подключить AuraDon</h2><ol class="guide-list"><li><strong>Создайте аккаунт</strong><p>Зарегистрируйтесь и сохраните код восстановления.</p></li><li><strong>Подключите телефон</strong><p>Откройте «Связь с телефоном» в Windows, подключите iPhone или Android и разрешите уведомления Kaspi.</p></li><li><strong>Запустите AuraDon</strong><p>Скопируйте код подключения в кабинете, вставьте его в программу и нажмите «Включить Kaspi».</p></li><li><strong>Добавьте виджет в эфир</strong><p>В разделе «Ссылки виджетов» скопируйте нужную ссылку и добавьте её как источник в TikTok LIVE Studio или OBS.</p></li></ol><p>Kaspi Gold: распознавание уведомлений. Halyk Bank, Freedom, ЮMoney и PayPal — скоро.</p>';$('#logged').append(instructions);
function applySection(){const sections={'widget-settings':editor,'designs':gallery,'links':links,'video-queue':document.querySelector('#video-queue'),'plans':pricing,'instructions':instructions};const key=location.hash.slice(1),selected=sections[key];const homeItems=new Set([$('#logged .profile'),$('#logged .notice'),pairButton,pairOutput]);for(const el of [...$('#logged').children])el.hidden=selected?el!==selected:!homeItems.has(el);document.querySelector('.welcome').hidden=!!selected&&!$('#logged').classList.contains('hidden');document.querySelectorAll('.sidebar a[href^="#"]').forEach(a=>a.classList.toggle('selected',a.getAttribute('href')==='#'+(selected?key:'home')));if(selected)window.scrollTo({top:0,behavior:'smooth'});}
window.addEventListener('hashchange',applySection);

me();
