const $ = selector => document.querySelector(selector);
const date = value => value ? new Date(value).toLocaleString('ru-RU') : '—';
let page = 0;
async function request(body) {
  const query = new URLSearchParams({page:String(page),search:$('#search').value});
  const r = await fetch('/api/cloud/admin/users'+(body?'':'?'+query), {method:body?'POST':'GET',headers:{Authorization:'Bearer '+$('#secret').value,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});
  const data = await r.json(); if(!r.ok) throw Error(data.error || 'Ошибка сервера'); return data;
}
async function load() {
  $('#error').textContent='';
  try {
    const data = await request(); const table=$('#users'); table.replaceChildren();
    $('#page-info').textContent='Страница '+(data.page+1);
    $('#previous').disabled=data.page===0; $('#next').disabled=!data.hasMore;
    for(const user of data.users) {
      const row=document.createElement('tr');
      for(const value of [user.username,date(user.trial_end),date(user.paid_end)]) {const cell=document.createElement('td');cell.textContent=value;row.append(cell);}
      const input=document.createElement('input');input.type='number';input.min='0';input.max='3660';input.value='30';input.setAttribute('aria-label','Дней доступа для '+user.username);
      const inputCell=document.createElement('td'),tier=document.createElement('select');tier.setAttribute('aria-label','Тариф для '+user.username);for(const name of ['pro','ultimate']){const option=document.createElement('option');option.value=name;option.textContent=name==='pro'?'Pro':'Ultimate';option.selected=user.paid_tier===name;tier.append(option);}inputCell.append(tier,input);row.append(inputCell);
      const button=document.createElement('button');button.textContent='Сохранить';button.onclick=async()=>{button.disabled=true;try{await request({userId:user.id,days:Number(input.value),tier:tier.value});await load();}catch(error){$('#error').textContent=error.message;}finally{button.disabled=false;}};
      const buttonCell=document.createElement('td');buttonCell.append(button);row.append(buttonCell);table.append(row);
    }
  } catch(error){$('#error').textContent=error.message || 'Нет соединения';}
}
$('#load').onclick=load;
$('#search-form').onsubmit=event=>{event.preventDefault();page=0;load();};
$('#previous').onclick=()=>{if(page>0){page--;load();}};
$('#next').onclick=()=>{page++;load();};
