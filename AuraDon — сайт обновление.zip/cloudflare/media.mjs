import {createHash} from 'node:crypto';
const hash=x=>createHash('sha256').update(x).digest('hex');
const allowed={'image/gif':'gif','image/png':'png','image/jpeg':'jpg','image/webp':'webp','video/mp4':'mp4','video/webm':'webm','audio/mpeg':'mp3','audio/wav':'wav','audio/ogg':'ogg'};
const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function mediaHandler(req,db){
  if(!db)return json({error:'Сервер не настроен'},503);
  const u=new URL(req.url),session=(req.headers.get('cookie')||'').match(/(?:^|;\s*)auradon_cloud_session=([a-f0-9]{64})(?:;|$)/)?.[1];
  const id=u.searchParams.get('id')||'',access=u.searchParams.get('access')||'';
  let owner,sessionOwner;
  if(session)sessionOwner=await db.prepare('SELECT user_id FROM sessions WHERE token_hash = ? AND expires_at > ?').bind(hash(session),Date.now()).first();
  owner=sessionOwner;
  if(!owner && /^[a-f0-9]{64}$/.test(access))owner=await db.prepare('SELECT user_id FROM devices WHERE relay_token = ? AND revoked_at IS NULL').bind(access).first();
  if(!owner)return json({error:'Доступ запрещён'},401);
  if(req.method==='GET'&&u.searchParams.has('list')){
    if(!sessionOwner)return json({error:'Войдите в аккаунт'},401);
    const prefix='user-media/'+sessionOwner.user_id+'/';
    const rows=await db.prepare('SELECT key,data FROM object_storage WHERE key LIKE ?').bind(prefix+'%/meta').all();
    return json({files:rows.results.map(row=>({id:row.key.slice(prefix.length,-5),...JSON.parse(new TextDecoder().decode(new Uint8Array(row.data)))}))});
  }
  if(req.method==='POST'){
    if(!sessionOwner||req.headers.get('origin')!==u.origin)return json({error:'Доступ запрещён'},403);
    const type=(req.headers.get('content-type')||'').split(';')[0];if(!allowed[type])return json({error:'Неподдерживаемый формат'},400);
    const size=Number(req.headers.get('content-length'));if(!Number.isFinite(size)||size<=0||size>20*1024*1024)return json({error:'Размер файла: до 20 МБ'},413);
    const bytes=new Uint8Array(await req.arrayBuffer());if(bytes.length!==size)return json({error:'Неверный размер'},400);
    const fileId=crypto.randomUUID(),base='user-media/'+owner.user_id+'/'+fileId,parts=Math.ceil(size/524288);
    // Reserve quota in one SQLite write so concurrent uploads cannot both
    // pass a separate read and exceed the user's limit.
    const reservation=await db.prepare("INSERT INTO object_storage (key,data) SELECT ?,? WHERE (SELECT COALESCE(SUM(json_extract(CAST(data AS TEXT),'$.size')),0) FROM object_storage WHERE key LIKE ?) + ? <= ?").bind(base+'/meta',new TextEncoder().encode(JSON.stringify({type,parts,size})),'user-media/'+owner.user_id+'/%/meta',size,20*1024*1024).run();
    if((reservation.meta?.changes??reservation.changes)!==1)return json({error:'Лимит медиатеки — 20 МБ'},413);
    const writes=[];for(let i=0;i<parts;i++)writes.push(db.prepare('INSERT INTO object_storage (key,data) VALUES (?,?)').bind(base+'/'+i,bytes.slice(i*524288,(i+1)*524288)));
    try {await db.batch(writes);} catch(error){await db.prepare('DELETE FROM object_storage WHERE key = ?').bind(base+'/meta').run();throw error;}
    return json({id:fileId,type,size});
  }
  if(req.method==='DELETE'){
    if(!sessionOwner||req.headers.get('origin')!==u.origin)return json({error:'Доступ запрещён'},403);
    if(!/^[a-f0-9-]{36}$/.test(id))return json({error:'Файл не найден'},404);
    const base='user-media/'+sessionOwner.user_id+'/'+id,meta=await db.prepare('SELECT data FROM object_storage WHERE key = ?').bind(base+'/meta').first();
    if(!meta)return json({error:'Файл не найден'},404);
    const key='user-settings/'+sessionOwner.user_id,row=await db.prepare('SELECT data FROM object_storage WHERE key = ?').bind(key).first();
    const writes=[db.prepare('DELETE FROM object_storage WHERE key LIKE ?').bind(base+'/%')];
    if(row){const settings=JSON.parse(new TextDecoder().decode(new Uint8Array(row.data)));if(settings.alertMediaId===id){delete settings.alertMediaId;writes.push(db.prepare('UPDATE object_storage SET data = ? WHERE key = ?').bind(new TextEncoder().encode(JSON.stringify(settings)),key));}}
    await db.batch(writes);return json({ok:true});
  }
  if(req.method!=='GET'||!/^[a-f0-9-]{36}$/.test(id))return json({error:'Файл не найден'},404);
  const base='user-media/'+owner.user_id+'/'+id,metaRow=await db.prepare('SELECT data FROM object_storage WHERE key = ?').bind(base+'/meta').first();if(!metaRow)return json({error:'Файл не найден'},404);
  const meta=JSON.parse(new TextDecoder().decode(new Uint8Array(metaRow.data)));if(!allowed[meta.type]||meta.parts<1||meta.parts>40||meta.size>20*1024*1024)return json({error:'Файл недоступен'},500);
  let i=0;const stream=new ReadableStream({async pull(controller){if(i>=meta.parts)return controller.close();const row=await db.prepare('SELECT data FROM object_storage WHERE key = ?').bind(base+'/'+i++).first();if(!row)return controller.error(Error('Файл повреждён'));controller.enqueue(new Uint8Array(row.data));}});
  return new Response(stream,{headers:{'Content-Type':meta.type,'Content-Length':String(meta.size),'X-Content-Type-Options':'nosniff','Cache-Control':'private, max-age=300'}});
}
