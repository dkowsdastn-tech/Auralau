import {createHash, randomBytes, randomUUID} from 'node:crypto';
import {entitlement} from './plans.mjs';
const hash = value => createHash('sha256').update(value).digest('hex');
const random = () => randomBytes(32).toString('hex');
const json = (body, status = 200) => Response.json(body, {status, headers:{'Cache-Control':'no-store'}});

export async function deviceHandler(request, db, now = Date.now()) {
  if (!db) return json({error:'Сервер аккаунтов не настроен'}, 503);
  const url = new URL(request.url), action = url.pathname.split('/').pop();
  if (request.method !== 'POST') return json({error:'Метод не поддерживается'},405);
  if (action === 'create') {
    if (request.headers.get('origin') !== url.origin) return json({error:'Недопустимый источник запроса'},403);
    const session = (request.headers.get('cookie') || '').match(/(?:^|;\s*)auradon_cloud_session=([a-f0-9]{64})(?:;|$)/)?.[1];
    if (!session) return json({error:'Войдите в аккаунт'},401);
    const user = await db.prepare('SELECT user_id FROM sessions WHERE token_hash = ? AND expires_at > ?').bind(hash(session),now).first();
    if (!user) return json({error:'Войдите в аккаунт'},401);
    const code = random();
    await db.prepare('INSERT INTO device_pairs (code_hash, user_id, expires_at) VALUES (?, ?, ?)').bind(hash(code), user.user_id, now+10*60*1000).run();
    return json({code,expiresAt:now+10*60*1000});
  }
  if (action === 'redeem') {
    let body; try {const text = await request.text(); if(text.length>1024)return json({error:'Слишком большой запрос'},413); body=JSON.parse(text);} catch {return json({error:'Неверный запрос'},400);}
    const code = String(body.code || '');
    if(!/^[a-f0-9]{64}$/.test(code))return json({error:'Неверный код подключения'},400);
    // DELETE RETURNING atomically consumes the single-use code.
    const pair = await db.prepare('DELETE FROM device_pairs WHERE code_hash = ? AND expires_at > ? RETURNING user_id').bind(hash(code),now).first();
    if (!pair) return json({error:'Код подключения истёк или уже использован'},401);
    const token=random(), id=randomUUID();
    await db.prepare('INSERT INTO devices (id, user_id, token_hash, created_at) VALUES (?, ?, ?, ?)').bind(id,pair.user_id,hash(token),now).run();
    return json({deviceId:id,token});
  }
  if (action === 'settings') {
    const token=(request.headers.get('authorization') || '').replace(/^Bearer /,'');
    if (!/^[a-f0-9]{64}$/.test(token)) return json({error:'Устройство не подключено'},401);
    const device=await db.prepare('SELECT user_id FROM devices WHERE token_hash = ? AND revoked_at IS NULL').bind(hash(token)).first();
    if (!device) return json({error:'Устройство не подключено'},401);
    const row=await db.prepare('SELECT data FROM object_storage WHERE key = ?').bind('user-settings/'+device.user_id).first();
    const settings=row?JSON.parse(new TextDecoder().decode(new Uint8Array(row.data))):{};
    const access=await db.prepare('SELECT trial_end,paid_end,paid_tier FROM entitlements WHERE user_id = ?').bind(device.user_id).first();
    const plan=entitlement({trialEnd:access?.trial_end,paidEnd:access?.paid_end,paidTier:access?.paid_tier},now);
    const voices=['ru-RU-SvetlanaNeural','ru-RU-DmitryNeural','kk-KZ-AigulNeural','kk-KZ-DauletNeural','en-US-JennyNeural','en-US-GuyNeural'];
    return json({tts:plan!=='free'&&settings.tts===true,ttsVoice:voices.includes(settings.ttsVoice)?settings.ttsVoice:'ru-RU-SvetlanaNeural',ttsOnlyMessage:settings.ttsOnlyMessage===true});
  }
  if (action === 'attach') {
    const token=(request.headers.get('authorization') || '').replace(/^Bearer /,'');
    if (!/^[a-f0-9]{64}$/.test(token)) return json({error:'Устройство не подключено'},401);
    const device=await db.prepare('SELECT id FROM devices WHERE token_hash = ? AND revoked_at IS NULL').bind(hash(token)).first();
    if (!device) return json({error:'Устройство не подключено'},401);
    let body; try {const text=await request.text();if(text.length>1024)return json({error:'Слишком большой запрос'},413);body=JSON.parse(text);} catch {return json({error:'Неверный запрос'},400);}
    if (!/^[a-f0-9]{64}$/.test(body.relayToken || '')) return json({error:'Неверная ссылка виджета'},400);
    try {await db.prepare('UPDATE devices SET relay_token = ? WHERE id = ?').bind(body.relayToken,device.id).run();}
    catch(e){if(/unique|constraint/i.test(String(e))) return json({error:'Виджет уже привязан к другому устройству'},409);throw e;}
    return json({ok:true});
  }
  return json({error:'Маршрут не найден'},404);
}
