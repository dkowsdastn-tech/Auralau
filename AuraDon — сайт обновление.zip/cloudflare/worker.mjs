import {createHash} from 'node:crypto';
import {relayHandler} from '../netlify/relay-handler.mjs';
import {adminHandler, restricted, entitlement} from './plans.mjs';
import {accountHandler} from './auth.mjs';
import {accountAdminHandler} from './admin.mjs';
import {deviceHandler} from './device.mjs';
import {d1Storage} from './d1-storage.mjs';
import {quoteHandler} from './pricing.mjs';
import {settingsHandler} from './settings.mjs';
import {mediaHandler} from './media.mjs';
import {videoHandler} from './video.mjs';
import {enqueueKaspiVideoLinks} from './video.mjs';
import {ALERT_GIFS} from '../public/alert-gifs.js';

const hash = value => createHash('sha256').update(value).digest('hex');
function storage(bucket) {return {
  async set(key,value){await bucket.put(key,value);},
  async setJSON(key,value){await bucket.put(key,JSON.stringify(value),{httpMetadata:{contentType:'application/json'}});},
  async get(key,{type='text'}={}){const value=await bucket.get(key);return !value?null:type==='json'?value.json():type==='arrayBuffer'?value.arrayBuffer():value.text();}
};}

export default {async fetch(req,env) {
  const url = new URL(req.url);
  if (url.pathname === '/.netlify/functions/speech') return Response.json({error:'Используется Edge TTS в приложении AuraDon'},{status:410});
  if (url.pathname.startsWith('/api/cloud/device/')) return deviceHandler(req,env.AURA_DB);
  if (url.pathname.startsWith('/api/cloud/auth/')) return accountHandler(req,env.AURA_DB);
  if (url.pathname === '/api/cloud/quote') return quoteHandler(req,env.AURA_DB);
  if (url.pathname === '/api/cloud/settings') return settingsHandler(req,env.AURA_DB);
  if (url.pathname === '/api/cloud/media') return mediaHandler(req,env.AURA_DB);
  if (url.pathname.startsWith('/api/cloud/video/')) {
    try { return await videoHandler(req,env.AURA_DB); }
    catch { return Response.json({error:'Сервис очереди временно недоступен. Проверьте миграцию базы AuraDon.'},{status:503,headers:{'Cache-Control':'no-store'}}); }
  }
  if (url.pathname === '/api/cloud/admin/users') return accountAdminHandler(req,env.AURA_DB,env.AURADON_ADMIN_SECRET);
  if (url.pathname === '/api/admin/plan') {
    if (env.AURA_DB || env.AURADON_LEGACY_DEMO !== '1') return new Response('Legacy plan API disabled',{status:404});
    if (!env.AURA_OVERLAYS) return new Response('Storage unavailable',{status:503});
    return adminHandler(req,env.AURA_OVERLAYS,env.AURADON_ADMIN_SECRET);
  }
  if (url.pathname === '/.netlify/functions/relay') {
    if (!env.AURA_OVERLAYS && !env.AURA_DB) return Response.json({error:'Хранилище не настроено'},{status:503});
    if (!env.AURA_DB && env.AURADON_LEGACY_DEMO !== '1') return Response.json({error:'База аккаунтов не настроена'},{status:503});
    const access=url.searchParams.get('access') || '', bucket=env.AURA_OVERLAYS || d1Storage(env.AURA_DB), store=storage(bucket);
    let plan, owner;
    if (env.AURA_DB) {
      if (!/^[a-f0-9]{64}$/.test(access)) return new Response('Not found',{status:404});
      owner=await env.AURA_DB.prepare('SELECT devices.user_id, devices.token_hash, entitlements.trial_end, entitlements.paid_end, entitlements.paid_tier FROM devices LEFT JOIN entitlements ON entitlements.user_id = devices.user_id WHERE devices.relay_token = ? AND devices.revoked_at IS NULL').bind(access).first();
      if (!owner) return new Response('Not found',{status:404});
      plan={trialEnd:owner.trial_end,paidEnd:owner.paid_end,paidTier:owner.paid_tier};
      // A viewer may fetch audio for an existing event via the read-only widget
      // link. Voice listing and synthesis requests require the paired device.
      if (req.method !== 'GET' || (url.pathname.endsWith('/speech') && url.searchParams.has('voices'))) {
        const device=req.headers.get('X-Auradon-Device') || '';
        if (!/^[a-f0-9]{64}$/.test(device) || hash(device)!==owner.token_hash) return new Response('Forbidden',{status:403});
      }
    } else {
      const record=await env.AURA_OVERLAYS.get('plans/'+access);
      plan=record?await record.json():null;
    }
    // Account settings may change independently of the device packet, so the
    // device packet's ETag alone cannot determine whether the overlay changed.
    const relayRequest=owner && req.method==='GET' && !url.searchParams.has('media') ? (()=>{const headers=new Headers(req.headers);headers.delete('if-none-match');return new Request(req,{headers});})() : req;
    let kaspiPacket=null,authorizedRelayRequest=relayRequest;
    if(owner&&req.method==='PUT'&&!url.searchParams.has('media')){
      try{
        kaspiPacket=await req.clone().json();
        if(Array.isArray(kaspiPacket?.deliveries)){
          const safePacket=structuredClone(kaspiPacket);
          const safeEvent=event=>{if(!event||typeof event!=='object')return event;const{videoUrl,...rest}=event;return rest;};
          safePacket.deliveries=safePacket.deliveries.map(delivery=>delivery?.event?{...delivery,event:safeEvent(delivery.event)}:delivery);
          if(safePacket.state){
            if(Array.isArray(safePacket.state.events))safePacket.state.events=safePacket.state.events.map(safeEvent);
            if(Array.isArray(safePacket.state.outbox))safePacket.state.outbox=safePacket.state.outbox.map(item=>item?.event?{...item,event:safeEvent(item.event)}:item);
            if(Array.isArray(safePacket.state.candidates))safePacket.state.candidates=safePacket.state.candidates.map(safeEvent);
          }
          const safeHeaders=new Headers(req.headers);safeHeaders.delete('content-length');
          authorizedRelayRequest=new Request(req,{headers:safeHeaders,body:JSON.stringify(safePacket)});
        }
      }catch{kaspiPacket=null;}
    }
    const result=await relayHandler(authorizedRelayRequest,store);
    if(owner&&req.method==='PUT'&&!url.searchParams.has('media')&&result.ok&&Array.isArray(kaspiPacket?.deliveries))
      await enqueueKaspiVideoLinks(env.AURA_DB,owner.user_id,kaspiPacket.deliveries,Date.now());
    if (!env.AURA_DB && req.method==='PUT' && result.ok && !url.searchParams.has('media')) {
      const key='plans/'+access;
      if (!await env.AURA_OVERLAYS.get(key)) await env.AURA_OVERLAYS.put(key,JSON.stringify({trialEnd:Date.now()+7*86400000,paidEnd:0}));
    }
    if (req.method==='GET' && !url.searchParams.has('media') && result.ok) {
      const packet=await result.json();
      if(owner && packet.state) {
        const row=await env.AURA_DB.prepare('SELECT data FROM object_storage WHERE key = ?').bind('user-settings/'+owner.user_id).first();
        if(row) {
          const saved=JSON.parse(new TextDecoder().decode(new Uint8Array(row.data)));
          if(saved.alertMediaId) saved.themeMedia={...(packet.state.settings.themeMedia||{}),[saved.theme||packet.state.settings.theme]:'/api/cloud/media?id='+encodeURIComponent(saved.alertMediaId)+'&access='+encodeURIComponent(access)};
          if(saved.alertGif&&saved.alertGif!=='custom'){const selected=ALERT_GIFS.find(g=>g.id===saved.alertGif),level=entitlement(plan);const url=selected&&(level==='ultimate'||level==='pro'&&selected.tier==='pro')?'/assets/'+selected.file:'/assets/auradon-pixel-a.png';saved.themeMedia=Object.fromEntries(['aura','nova','glass','pixel'].map(id=>[id,url]));saved.gif='';}
          packet.state.settings={...packet.state.settings,...saved};
        }
      }
      return Response.json(restricted(packet,plan),{headers:{'Cache-Control':'no-store'}});
    }
    return result;
  }
  if (['/overlay','/overlay/','/studio','/studio/'].includes(url.pathname)) {
    // The production bundle keeps these entry points in the public root.
    // Do not rewrite to /overlay/index.html or /studio/index.html: those
    // directories are not part of the deployed static asset tree.
    url.pathname=url.pathname.startsWith('/overlay')?'/overlay.html':'/index.html';
    return env.ASSETS.fetch(new Request(url,req));
  }
  return env.ASSETS.fetch(req);
}};
