export const ALERT_GIFS=[
  {id:'heart',file:'DDg.gif',name:'Пиксельное сердце',tier:'pro'},
  {id:'freedom',file:'1CQY.gif',name:'Энергия',tier:'pro'},
  {id:'cloud',file:'xv.gif',name:'Денежное облако',tier:'pro'},
  {id:'rain',file:'VwCN.gif',name:'Денежный дождь',tier:'pro'},
  {id:'wings',file:'xt.gif',name:'Крылатые деньги',tier:'pro'},
  {id:'coin',file:'ZXv0.gif',name:'Пиксельная монета',tier:'pro'},
  {id:'jar',file:'donate-jar.gif',name:'Копилка',tier:'pro'},
  {id:'button',file:'donate-button.gif',name:'Кнопка доната',tier:'pro'},
  {id:'text',file:'donate-type.gif',name:'Donate',tier:'pro'},
  {id:'earth',file:'donate-earth.gif',name:'Планета поддержки',tier:'pro'},
  {id:'diamond',file:'4V0V.gif',name:'Алмаз',tier:'ultimate'},
  {id:'cash',file:'2r6D.gif',name:'Пачка денег',tier:'ultimate'},
  {id:'moment',file:'Ldv.gif',name:'Момент',tier:'ultimate'},
  {id:'streamer',file:'streamer.gif',name:'Стример',tier:'ultimate'}
];
