export {onRequest} from '../cloudflare/pages-adapter.mjs';
