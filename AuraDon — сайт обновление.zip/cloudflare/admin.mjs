import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';

const digest = value => createHash('sha256').update(value).digest();
const hash = value => digest(value).toString('hex');
const response = (body, status = 200) => Response.json(body, {status, headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const sameSecret = (left, right) => timingSafeEqual(digest(left), digest(right));
const MAX_BODY = 4096;
const RATE_WINDOW = 15 * 60 * 1000;
const RATE_LIMIT = 12;

async function failedAttempts(db, ip, now) {
  const key = hash(`admin:${ip}`), windowStart = now - RATE_WINDOW;
  const row = await db.prepare('INSERT INTO auth_attempts (key,window_start,count) VALUES (?,?,1) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window_start<? THEN 1 ELSE count+1 END,window_start=CASE WHEN window_start<? THEN ? ELSE window_start END RETURNING count').bind(key,now,windowStart,windowStart,now).first();
  return Number(row?.count || 1);
}

// Separate server-only credential. It is never returned by this API.
export async function accountAdminHandler(request, db, secret, now = Date.now()) {
  if (!db || !secret || secret.length < 32) return response({error:'Панель не настроена'}, 503);
  const ip = request.headers.get('CF-Connecting-IP');
  if (!ip) return response({error:'Источник подключения не определён'}, 403);
  const url = new URL(request.url);
  if (request.method === 'POST' && request.headers.get('origin') !== url.origin) return response({error:'Недопустимый источник запроса'}, 403);

  const supplied = String(request.headers.get('authorization') || '').replace(/^Bearer\s+/i, '').slice(0, 512);
  if (!sameSecret(supplied, secret)) {
    const attempts = await failedAttempts(db, ip, now);
    return response({error:attempts > RATE_LIMIT ? 'Слишком много попыток. Подождите 15 минут.' : 'Доступ запрещён'}, attempts > RATE_LIMIT ? 429 : 403);
  }
  const rateKey = hash(`admin:${ip}`);
  await db.prepare('DELETE FROM auth_attempts WHERE key=?').bind(rateKey).run();

  if (request.method === 'GET') {
    const auditUserId = String(url.searchParams.get('audit') || '').slice(0, 64);
    if (auditUserId) {
      const exists = await db.prepare('SELECT id FROM users WHERE id=?').bind(auditUserId).first();
      if (!exists) return response({error:'Аккаунт не найден'}, 404);
      const audit = await db.prepare('SELECT action,created_at FROM admin_audit WHERE user_id=? ORDER BY created_at DESC LIMIT 100').bind(auditUserId).all();
      return response({audit:audit.results || []});
    }
    const page = Math.max(0, Math.min(100000, Number.parseInt(url.searchParams.get('page') || '0', 10) || 0));
    const search = (url.searchParams.get('search') || '').trim().normalize('NFC').toLowerCase().slice(0, 32);
    const data = await db.prepare("SELECT users.id,users.username,users.created_at,COALESCE(entitlements.trial_end,0) AS trial_end,COALESCE(entitlements.paid_end,0) AS paid_end,COALESCE(entitlements.paid_tier,'pro') AS paid_tier,(SELECT COUNT(*) FROM sessions WHERE sessions.user_id=users.id AND sessions.expires_at>?) AS active_sessions,(SELECT COUNT(*) FROM devices WHERE devices.user_id=users.id AND devices.revoked_at IS NULL) AS active_devices FROM users LEFT JOIN entitlements ON entitlements.user_id=users.id WHERE instr(users.username_key,?)>0 OR ?='' ORDER BY users.created_at DESC,users.id LIMIT 101 OFFSET ?").bind(now,search,search,page*100).all();
    return response({users:(data.results || []).slice(0,100),page,hasMore:(data.results || []).length>100});
  }
  if (request.method !== 'POST') return response({error:'Метод не поддерживается'}, 405);

  let body;
  try {
    const text = await request.text();
    if (text.length > MAX_BODY) return response({error:'Слишком большой запрос'}, 413);
    body = JSON.parse(text);
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('invalid body');
  } catch { return response({error:'Неверный запрос'}, 400); }

  const userId = String(body.userId || '').slice(0, 64);
  const user = await db.prepare('SELECT id FROM users WHERE id=?').bind(userId).first();
  if (!user) return response({error:'Аккаунт не найден'}, 404);
  const action = body.action || 'grant';

  if (action === 'recovery_code') {
    const code = randomBytes(32).toString('hex');
    await db.batch([
      db.prepare('UPDATE users SET recovery_hash=? WHERE id=?').bind(hash(code),user.id),
      db.prepare('INSERT INTO admin_audit (id,user_id,action,created_at) VALUES (?,?,?,?)').bind(randomUUID(),user.id,'recovery_code_issued',now)
    ]);
    return response({ok:true,recoveryCode:code,oneTime:true});
  }

  if (action === 'revoke_sessions') {
    await db.batch([
      db.prepare('DELETE FROM sessions WHERE user_id=?').bind(user.id),
      db.prepare('UPDATE devices SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').bind(now,user.id),
      db.prepare('DELETE FROM device_pairs WHERE user_id=?').bind(user.id),
      db.prepare('INSERT INTO admin_audit (id,user_id,action,created_at) VALUES (?,?,?,?)').bind(randomUUID(),user.id,'sessions_and_devices_revoked',now)
    ]);
    return response({ok:true});
  }

  if (action !== 'grant') return response({error:'Неизвестное действие'},400);
  const days = Number(body.days);
  if (!Number.isInteger(days) || days < 0 || days > 3660) return response({error:'Укажите срок от 0 до 3660 дней'},400);
  const tier = body.tier || 'pro';
  if (!['pro','ultimate'].includes(tier)) return response({error:'Выберите Pro или Ultimate'},400);
  await db.batch([
    db.prepare('INSERT INTO entitlements (user_id,trial_end,paid_end,paid_tier) VALUES (?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET trial_end=CASE WHEN ?=0 THEN 0 ELSE entitlements.trial_end END,paid_end=CASE WHEN ?=0 THEN 0 WHEN entitlements.paid_tier=? AND entitlements.paid_end>? THEN entitlements.paid_end+? ELSE ? END,paid_tier=excluded.paid_tier').bind(user.id,0,days?now+days*86400000:0,tier,days,days,tier,now,days*86400000,days?now+days*86400000:0),
    db.prepare('INSERT INTO admin_audit (id,user_id,action,created_at) VALUES (?,?,?,?)').bind(randomUUID(),user.id,`${tier}_days:${days}`,now)
  ]);
  const updated = await db.prepare('SELECT paid_end,paid_tier,trial_end FROM entitlements WHERE user_id=?').bind(user.id).first();
  return response({ok:true,paidEnd:updated.paid_end,paidTier:updated.paid_tier,trialEnd:updated.trial_end});
}
