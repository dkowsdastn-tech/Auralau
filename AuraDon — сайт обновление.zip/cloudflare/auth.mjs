import { randomBytes, randomUUID, pbkdf2, createHash, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import {entitlement} from './plans.mjs';

const hash = value => createHash('sha256').update(value).digest('hex');
// Cloudflare caps each PBKDF2 invocation at 100,000 iterations. Version the
// salt so existing accounts keep their original derivation when supported.
const derive = async (password, salt) => {
  if (!salt.startsWith('v2:')) return (await promisify(pbkdf2)(password, salt, 310000, 32, 'sha256')).toString('hex');
  let value = Buffer.from(password);
  for (let i = 0; i < 6; i++) value = await promisify(pbkdf2)(value, `${salt}:${i}`, 100000, 32, 'sha256');
  return value.toString('hex');
};
const random = () => randomBytes(32).toString('hex');
const equal = (a, b) => timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));
const json = (data, status = 200, headers = {}) => Response.json(data, {status, headers: {'Cache-Control':'no-store', ...headers}});
const cookie = (value, age) => `auradon_cloud_session=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`;
const SESSION_SECONDS = 60 * 60 * 24 * 7;

export async function accountHandler(request, db, now = Date.now()) {
  if (!db) return json({error:'Сервер аккаунтов не настроен'}, 503);
  const url = new URL(request.url);
  const action = url.pathname.split('/').pop();
  if (request.method === 'POST' && request.headers.get('origin') !== url.origin)
    return json({error:'Недопустимый источник запроса'}, 403);
  const session = (request.headers.get('cookie') || '').match(/(?:^|;\s*)auradon_cloud_session=([a-f0-9]{64})(?:;|$)/)?.[1];
  if (action === 'trial-count' && request.method === 'GET') {const row=await db.prepare('SELECT COUNT(*) AS count FROM trial_claims').first();return json({claimed:Math.min(333,Number(row?.count||0)),limit:333});}
  if (action === 'me' && request.method === 'GET') {
    if (!session) return json({error:'Войдите в аккаунт'}, 401);
    const row = await db.prepare('SELECT users.id, users.username FROM sessions JOIN users ON users.id = sessions.user_id WHERE sessions.token_hash = ? AND sessions.expires_at > ?').bind(hash(session), now).first();
    if (!row) return json({error:'Войдите в аккаунт'}, 401);
    const device = await db.prepare('SELECT relay_token FROM devices WHERE user_id = ? AND relay_token IS NOT NULL AND revoked_at IS NULL ORDER BY created_at DESC LIMIT 1').bind(row.id).first();
    const access=await db.prepare('SELECT trial_end, paid_end, paid_tier FROM entitlements WHERE user_id = ?').bind(row.id).first();
    return json({user:row,overlayToken:device?.relay_token || null,plan:entitlement({trialEnd:access?.trial_end,paidEnd:access?.paid_end,paidTier:access?.paid_tier},now)});
  }
  if (request.method !== 'POST') return json({error:'Метод не поддерживается'}, 405);
  if (action === 'logout') {
    if (session) await db.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(hash(session)).run();
    return json({ok:true}, 200, {'Set-Cookie':cookie('', 0)});
  }
  if (!['register','login','recover'].includes(action)) return json({error:'Маршрут не найден'}, 404);
  let body;
  try {
    const text = await request.text();
    if (text.length > 4096) return json({error:'Слишком большой запрос'}, 413);
    body = JSON.parse(text);
  } catch { return json({error:'Неверный запрос'}, 400); }
  const username = String(body.username || '').trim().normalize('NFC'), password = String(body.password || '');
  const usernameKey = username.toLowerCase().normalize('NFC');
  if (!/^[\p{L}\d_-]{3,32}$/u.test(username) || password.length < 10 || password.length > 128)
    return json({error:'Логин: 3–32 символа; пароль: 10–128 символов'}, 400);
  const ip = request.headers.get('CF-Connecting-IP');
  if (!ip) return json({error:'Источник подключения не определён'}, 403);
  const rateKey = hash(ip), windowStart = now - 15 * 60 * 1000;
  const limit = await db.prepare('INSERT INTO auth_attempts (key, window_start, count) VALUES (?, ?, 1) ON CONFLICT(key) DO UPDATE SET count = CASE WHEN window_start < ? THEN 1 ELSE count + 1 END, window_start = CASE WHEN window_start < ? THEN ? ELSE window_start END RETURNING count').bind(rateKey, now, windowStart, windowStart, now).first();
  if (limit.count > 30) return json({error:'Слишком много попыток. Попробуйте позже'}, 429);
  let user, recovery;
  if (action === 'register') {
    const id = randomUUID(), salt = 'v2:' + random(), passwordHash = await derive(password, salt);
    recovery = random();
    try {
      await db.batch([
        db.prepare('INSERT INTO users (id, username, username_key, password_salt, password_hash, recovery_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').bind(id, username, usernameKey, salt, passwordHash, hash(recovery), now),
        db.prepare('INSERT INTO trial_claims (user_id,claimed_at) SELECT ?,? WHERE (SELECT COUNT(*) FROM trial_claims) < 333').bind(id,now),
        db.prepare('INSERT INTO entitlements (user_id, trial_end) SELECT ?, CASE WHEN EXISTS (SELECT 1 FROM trial_claims WHERE user_id=?) THEN ? ELSE 0 END').bind(id,id,now + 7 * 86400000)
      ]);
    } catch (e) {
      if (/unique|constraint/i.test(String(e))) return json({error:'Этот логин уже занят'}, 409);
      throw e;
    }
    user = {id, username};
  } else if (action === 'recover') {
    const row = await db.prepare('SELECT id, username, recovery_hash FROM users WHERE username_key = ?').bind(usernameKey).first();
    const supplied = hash(String(body.recovery || '').slice(0, 256));
    if (!equal(supplied, row?.recovery_hash || '0'.repeat(64)) || !row)
      return json({error:'Неверный логин или код восстановления'}, 401);
    const salt = 'v2:' + random();
    recovery = random();
    const result = await db.prepare('UPDATE users SET password_salt = ?, password_hash = ?, recovery_hash = ? WHERE id = ? AND recovery_hash = ?').bind(salt, await derive(password, salt), hash(recovery), row.id, row.recovery_hash).run();
    if ((result.meta?.changes ?? result.changes) !== 1) return json({error:'Код восстановления уже использован'}, 409);
    await db.batch([
      db.prepare('DELETE FROM sessions WHERE user_id = ?').bind(row.id),
      db.prepare('UPDATE devices SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL').bind(now,row.id),
      db.prepare('DELETE FROM device_pairs WHERE user_id = ?').bind(row.id)
    ]);
    user = {id:row.id, username:row.username};
  } else {
    const row = await db.prepare('SELECT id, username, password_salt, password_hash FROM users WHERE username_key = ?').bind(usernameKey).first();
    const actual = await derive(password, row?.password_salt || 'v2:' + '0'.repeat(64));
    if (!equal(actual, row?.password_hash || '0'.repeat(64)) || !row)
      return json({error:'Неверный логин или пароль'}, 401);
    user = {id:row.id, username:row.username};
  }
  const token = random();
  await db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)').bind(hash(token), user.id, now + SESSION_SECONDS * 1000).run();
  return json({user, ...(recovery ? {recovery} : {})}, action === 'register' ? 201 : 200, {'Set-Cookie':cookie(token, SESSION_SECONDS)});
}
