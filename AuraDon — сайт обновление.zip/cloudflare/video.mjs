import {createHash, randomUUID} from 'node:crypto';
import {entitlement} from './plans.mjs';

const hash = value => createHash('sha256').update(value).digest('hex');
const json = (body, status=200) => Response.json(body,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const sessionCookie = request => (request.headers.get('cookie')||'').match(/(?:^|;\s*)auradon_cloud_session=([a-f0-9]{64})(?:;|$)/)?.[1] || '';
const allowedVideoHosts = new Set(['youtube.com','www.youtube.com','m.youtube.com','youtu.be']);

export function parseYouTubeVideoId(input) {
  let url;
  try { url = new URL(String(input||'')); } catch { return null; }
  if (url.protocol !== 'https:' || !allowedVideoHosts.has(url.hostname.toLowerCase())) return null;
  let id='';
  if (url.hostname.toLowerCase().endsWith('youtu.be')) id=url.pathname.split('/').filter(Boolean)[0]||'';
  else if (url.pathname === '/watch') id=url.searchParams.get('v')||'';
  else if (/^\/(?:shorts|live|embed)\/[\w-]+/.test(url.pathname)) id=url.pathname.split('/')[2]||'';
  return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
}

const resolvePlan = row => entitlement({trialEnd:row?.trial_end,paidEnd:row?.paid_end,paidTier:row?.paid_tier});
async function ownerFor(request,db,now) {
  const token=sessionCookie(request); if(!token)return null;
  return db.prepare('SELECT users.id,users.username,entitlements.trial_end,entitlements.paid_end,entitlements.paid_tier FROM sessions JOIN users ON users.id=sessions.user_id LEFT JOIN entitlements ON entitlements.user_id=users.id WHERE sessions.token_hash=? AND sessions.expires_at>?').bind(hash(token),now).first();
}
async function getSettings(db,userId) {
  return await db.prepare('SELECT enabled,volume,panic,min_amount,max_seconds,position,widget_width FROM video_stream_settings WHERE user_id=?').bind(userId).first() || {enabled:0,volume:50,panic:0,min_amount:500,max_seconds:180,position:'right',widget_width:420};
}
async function startNext(db,userId,now) {
  const result=await db.prepare(`UPDATE video_requests SET status='playing',updated_at=? WHERE id=(SELECT next.id FROM video_requests AS next JOIN video_stream_settings AS cfg ON cfg.user_id=next.user_id WHERE next.user_id=? AND next.status='queued' AND cfg.enabled=1 AND cfg.panic=0 AND NOT EXISTS(SELECT 1 FROM video_requests AS current WHERE current.user_id=next.user_id AND current.status='playing') ORDER BY next.created_at,next.id LIMIT 1) AND status='queued' RETURNING id`).bind(now,userId).first();
  return result?.id || null;
}
async function activePlayer(db,access,now) {
  if(!/^[a-f0-9]{64}$/.test(access))return null;
  return db.prepare('SELECT devices.user_id,devices.token_hash,video_stream_settings.enabled,video_stream_settings.volume,video_stream_settings.panic,video_stream_settings.min_amount,video_stream_settings.max_seconds,video_stream_settings.position,video_stream_settings.widget_width,entitlements.trial_end,entitlements.paid_end,entitlements.paid_tier FROM devices JOIN users ON users.id=devices.user_id LEFT JOIN video_stream_settings ON video_stream_settings.user_id=users.id LEFT JOIN entitlements ON entitlements.user_id=users.id WHERE devices.relay_token=? AND devices.revoked_at IS NULL').bind(access).first();
}
const activePlan = row => entitlement({trialEnd:row?.trial_end,paidEnd:row?.paid_end,paidTier:row?.paid_tier});

// Consume verified, non-test Phone Link donation deliveries. The Kaspi video
// URL is deliberately persisted only as a validated YouTube video ID.
export async function enqueueKaspiVideoLinks(db,userId,deliveries,now=Date.now()) {
  if(!db||!Array.isArray(deliveries)||deliveries.length===0)return 0;
  const access=await db.prepare('SELECT trial_end,paid_end,paid_tier FROM entitlements WHERE user_id=?').bind(userId).first();
  if(activePlan(access)!=='ultimate')return 0;
  const settings=await getSettings(db,userId);
  if(Number(settings.enabled)!==1||Number(settings.panic)===1)return 0;
  const queued=await db.prepare("SELECT COUNT(*) AS count FROM video_requests WHERE user_id=? AND status IN ('queued','playing')").bind(userId).first();
  let added=0;
  for(const delivery of deliveries.slice(-100)){
    const event=delivery?.event;
    if(!event||event.source!=='phone'||event.test!==false||event.kind!=='donation'||! /^[a-f0-9-]{36}$/i.test(String(event.id||'')))continue;
    const amount=Number(event.amount),youtubeId=parseYouTubeVideoId(event.videoUrl);
    if(!youtubeId||!Number.isFinite(amount)||amount<Number(settings.min_amount??500)||amount>1e7)continue;
    if(Number(queued?.count||0)+added>=50)break;
    const name=String(event.name||'Аноним').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,40)||'Аноним';
    const message=String(event.message||'').replace(/https?:\/\/\S+/giu,'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,240);
    const id=randomUUID();
    const result=await db.prepare("INSERT OR IGNORE INTO video_requests (id,user_id,requester_name,youtube_id,message,status,created_at,updated_at,donation_amount,donation_event_id) VALUES (?,?,?,?,?,'queued',?,?,?,?)").bind(id,userId,name,youtubeId,message,Number(event.createdAt&&Date.parse(event.createdAt))||now,now,amount,event.id).run();
    const changes=result.meta?.changes??result.changes??0;
    if(Number(changes)>0){added++;await startNext(db,userId,now);}
  }
  return added;
}

export async function videoHandler(request,db,now=Date.now()) {
  if(!db)return json({error:'Сервер аккаунтов не настроен'},503);
  const url=new URL(request.url),route=url.pathname.split('/').pop();

  if(route==='profile' && request.method==='GET'){
    const username=String(url.searchParams.get('streamer')||'').trim().normalize('NFC');
    if(!/^[\p{L}\d_-]{3,32}$/u.test(username))return json({error:'Укажите корректный логин стримера'},400);
    const user=await db.prepare('SELECT id,username FROM users WHERE username_key=?').bind(username.toLowerCase().normalize('NFC')).first();
    if(!user)return json({error:'Стример не найден'},404);
    const [settings,access]=await Promise.all([
      getSettings(db,user.id),
      db.prepare('SELECT trial_end,paid_end,paid_tier FROM entitlements WHERE user_id=?').bind(user.id).first()
    ]);
    const enabled=activePlan(access)!=='free' && settings.enabled===1;
    return json({username:user.username,enabled,reason:enabled?'':settings.enabled?'plan':'disabled'});
  }

  if(route==='request' && request.method==='POST')return json({error:'Отправьте YouTube-ссылку в комментарии к переводу Kaspi. Отдельная форма больше не используется.'},410);

  if(route==='player' && request.method==='GET'){
    const row=await activePlayer(db,url.searchParams.get('access')||'',now);
    if(!row||activePlan(row)!=='ultimate')return json({error:'Виджет недоступен'},404);
    const settings={enabled:Number(row.enabled)===1,volume:Number(row.volume??50),panic:Number(row.panic)===1,minAmount:Number(row.min_amount??500),maxSeconds:Number(row.max_seconds??180),position:row.position==='left'?'left':'right',widgetWidth:Number(row.widget_width??420)};
    if(!settings.enabled||settings.panic)return json({settings,current:null});
    const current=await db.prepare("SELECT id,requester_name,youtube_id,message,donation_amount,created_at FROM video_requests WHERE user_id=? AND status='playing' ORDER BY updated_at DESC LIMIT 1").bind(row.user_id).first();
    return json({settings,current:current||null});
  }

  if(route==='complete' && request.method==='POST'){
    if(request.headers.get('origin')!==url.origin)return json({error:'Недопустимый источник запроса'},403);
    const access=url.searchParams.get('access')||'',row=await activePlayer(db,access,now);
    if(!row||activePlan(row)!=='ultimate')return json({error:'Виджет недоступен'},404);
    let body;try{const text=await request.text();if(text.length>512)return json({error:'Слишком большой запрос'},413);body=JSON.parse(text);}catch{return json({error:'Неверный запрос'},400);}
    if(!/^[a-f0-9-]{36}$/i.test(body.id||''))return json({error:'Неверный элемент очереди'},400);
    const status=body.outcome==='failed'?'failed':'completed';
    const result=await db.prepare("UPDATE video_requests SET status=?,updated_at=? WHERE id=? AND user_id=? AND status='playing'").bind(status,now,body.id,row.user_id).run();
    if((result.meta?.changes??result.changes??0)>0 && Number(row.panic)!==1)await startNext(db,row.user_id,now);
    return json({ok:true});
  }

  const owner=await ownerFor(request,db,now);
  if(route==='queue' && request.method==='GET'){
    if(!owner)return json({error:'Войдите в аккаунт'},401);
    if(activePlan(owner)!=='ultimate')return json({error:'YouTube Media Player доступен только на тарифе Ultimate'},403);
    const [settings,items]=await Promise.all([
      getSettings(db,owner.id),
      db.prepare("SELECT id,requester_name,youtube_id,message,status,donation_amount,created_at FROM video_requests WHERE user_id=? ORDER BY CASE status WHEN 'playing' THEN 0 WHEN 'queued' THEN 1 ELSE 2 END, created_at ASC LIMIT 60").bind(owner.id).all()
    ]);
    return json({settings,requests:items.results||[]});
  }
  if(route==='manage' && request.method==='POST'){
    if(request.headers.get('origin')!==url.origin)return json({error:'Недопустимый источник запроса'},403);
    if(!owner)return json({error:'Войдите в аккаунт'},401);
    if(activePlan(owner)!=='ultimate')return json({error:'YouTube Media Player доступен только на тарифе Ultimate'},403);
    let body;try{const text=await request.text();if(text.length>1024)return json({error:'Слишком большой запрос'},413);body=JSON.parse(text);}catch{return json({error:'Неверный запрос'},400);}
    const action=String(body.action||''),settings=await getSettings(db,owner.id);
    if(action==='settings'){
      const minAmount=Number(body.minAmount??settings.min_amount??500),maxSeconds=Number(body.maxSeconds??settings.max_seconds??180),widgetWidth=Number(body.widgetWidth??settings.widget_width??420),position=String(body.position??settings.position??'right');
      if(typeof body.enabled!=='boolean'||!Number.isInteger(Number(body.volume))||Number(body.volume)<0||Number(body.volume)>100||!Number.isInteger(minAmount)||minAmount<100||minAmount>1e7||!Number.isInteger(maxSeconds)||maxSeconds<15||maxSeconds>600||!Number.isInteger(widgetWidth)||![420,520].includes(widgetWidth)||!['left','right'].includes(position))return json({error:'Проверьте громкость, сумму, длительность и размещение виджета'},400);
      const enabled=body.enabled?1:0,volume=Number(body.volume),panic=enabled?0:1;
      await db.prepare('INSERT INTO video_stream_settings (user_id,enabled,volume,panic,min_amount,max_seconds,position,widget_width,updated_at) VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled,volume=excluded.volume,panic=excluded.panic,min_amount=excluded.min_amount,max_seconds=excluded.max_seconds,position=excluded.position,widget_width=excluded.widget_width,updated_at=excluded.updated_at').bind(owner.id,enabled,volume,panic,minAmount,maxSeconds,position,widgetWidth,now).run();
      if(enabled)await startNext(db,owner.id,now);
      if(!enabled)await db.prepare("UPDATE video_requests SET status='stopped',updated_at=? WHERE user_id=? AND status='playing'").bind(now,owner.id).run();
      return json({ok:true});
    }
    if(action==='play'){
      if(settings.enabled!==1)return json({error:'Сначала включите видеозаявки'},409);
      await db.prepare('UPDATE video_stream_settings SET panic=0,updated_at=? WHERE user_id=?').bind(now,owner.id).run();
      await startNext(db,owner.id,now);return json({ok:true});
    }
    if(action==='skip'){
      if(settings.enabled!==1)return json({error:'Сначала включите видеоплеер'},409);
      await db.prepare("UPDATE video_requests SET status='skipped',updated_at=? WHERE user_id=? AND status='playing'").bind(now,owner.id).run();
      await db.prepare('UPDATE video_stream_settings SET panic=0,updated_at=? WHERE user_id=?').bind(now,owner.id).run();
      await startNext(db,owner.id,now);return json({ok:true});
    }
    if(action==='panic'){
      await db.prepare('INSERT INTO video_stream_settings (user_id,enabled,volume,panic,updated_at) VALUES (?,1,?,1,?) ON CONFLICT(user_id) DO UPDATE SET panic=1,updated_at=excluded.updated_at').bind(owner.id,Number(settings.volume??50),now).run();
      await db.prepare("UPDATE video_requests SET status='stopped',updated_at=? WHERE user_id=? AND status='playing'").bind(now,owner.id).run();
      return json({ok:true});
    }
    if(action==='resume'){
      if(settings.enabled!==1)return json({error:'Сначала включите видеоплеер'},409);
      await db.prepare('UPDATE video_stream_settings SET panic=0,updated_at=? WHERE user_id=?').bind(now,owner.id).run();
      await startNext(db,owner.id,now);return json({ok:true});
    }
    return json({error:'Неизвестное действие'},400);
  }
  return json({error:'Маршрут не найден'},404);
}
