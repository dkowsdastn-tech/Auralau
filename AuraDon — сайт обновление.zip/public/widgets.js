import{esc,money,totals}from'./shared.js';
import{t}from'./i18n.js';
import{TOP_STYLES}from'./top-catalog.js';
const styles=new Set(TOP_STYLES.map(item=>item.id));
export function renderTop(events,s,title='Топ дня'){
 const rows=totals(events).top.slice(0,Math.max(1,Math.min(20,Number(s.topCount)||5)));
 const style=styles.has(s.topStyle)?s.topStyle:'rainbow',layout=['vertical','horizontal','ticker','rotate'].includes(s.topLayout)?s.topLayout:'vertical';
 const content=rows.map(([name,amount],i)=>`<div class="aura-rank" data-donor="${esc(name)}" style="--rank:${i};--hue:${(i*63+265)%360};--cycle:${Math.max(1,rows.length)*4}s"><span class="rank-medal">${style==='medals'&&i<3?['🥇','🥈','🥉'][i]:i+1}</span><strong class="donor-name" data-no-translate>${esc(name)}</strong><b>${money(amount)}</b></div>`).join('');
 return `<section class="aura-top rank-${style} layout-${layout} rank-motion-${['slide','float','none'].includes(s.topMotion)?s.topMotion:'slide'}" style="--rank-font:${esc(s.topFont||'Oswald')};--live-accent:${/^#[a-f\d]{6}$/i.test(s.topAccent||'')?s.topAccent:'#ffd12b'};--ticker-speed:${Number(s.tickerSpeed)||24}s"><header>${esc(t(title))}</header>${rows.length?`<div class="rank-viewport"><div class="rank-track">${content}${layout==='ticker'?`<div class="rank-copy" aria-hidden="true">${content}</div>`:''}</div></div>`:`<p class="rank-empty">${esc(t('Первый герой ещё впереди'))}</p>`}</section>`;
}
export function renderGoal(sum,s){
 const target=Math.max(1,Number(s.goalTarget)||1),value=Math.max(0,Number(sum)||0),percent=Math.min(100,100*value/target),style=['aurora','neon','battery','classic','tiktok','prism','sunset','mint','broadcast','tube','goldbar','icebar','rosebar','limebar','chrome','minimal'].includes(s.goalStyle)?s.goalStyle:'aurora';
 return `<section class="aura-goal goal-${style}" style="--bar-accent:${/^#[a-f\d]{6}$/i.test(s.goalAccent||'')?s.goalAccent:'#ffcf26'}"><header><strong data-no-translate>${esc(s.goalName)}</strong><b>${Math.round(percent)}%</b></header><div class="goal-meter" role="progressbar" data-no-translate aria-label="${esc(s.goalName)}" aria-valuenow="${Math.min(value,target)}" aria-valuemin="0" aria-valuemax="${target}"><div class="goal-fill" style="width:${percent}%"></div>${style==='battery'?'<div class="battery-cells">'+Array.from({length:10},()=>'<i></i>').join('')+'</div>':''}</div><footer><b>${money(value)}</b><span>${money(target)}</span></footer></section>`;
}
