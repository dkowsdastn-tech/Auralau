import {createHash,timingSafeEqual} from 'node:crypto';
const hash=value=>createHash('sha256').update(value).digest('hex');
const promoHashes={pro:'0a627a515c732c3b9247fdb5871af7634eff8de83a3673894b7d6a83a311e87e',ultimate:'22bff8c56f8c4f479fde0ad8b4e8af0fb93ae95092c0eb1f4ed13acc70be4f47'};
const same=(a,b)=>timingSafeEqual(Buffer.from(a,'hex'),Buffer.from(b,'hex'));

// Quotes are estimates for manual Telegram purchases. They do not grant access
// and do not verify that a customer is eligible for a first-purchase offer.
export function calculateQuote({tier,days,intro=false,promo=''}){
  if(!['pro','ultimate'].includes(tier))throw Error('Выберите тариф Pro или Ultimate');
  days=Number(days);
  if(!Number.isInteger(days)||days<7||days>3660)throw Error('Срок: от 7 до 3660 дней');
  promo=String(promo||'').trim().toLowerCase().replace(/\s+/g,' ');
  if(promo.length>100)throw Error('Неверный промокод');
  if(intro){if(days!==30)throw Error('Первая покупка со скидкой действует 30 дней');if(promo)throw Error('Промокод нельзя применить к первой покупке');return{tier,days,intro:true,amount:tier==='pro'?990:2490,discount:0,eligiblePromo:false};}
  let amount=Math.max(tier==='pro'?449:682,Math.round((tier==='pro'?2990:4990)*days/60)),discount=0;
  const eligiblePromo=days>=180&&days<=730;
  if(promo){if(!eligiblePromo||!same(hash(promo),promoHashes[tier]))throw Error('Промокод не подходит к тарифу или сроку');discount=20;amount=Math.round(amount*.8);}
  return{tier,days,intro:false,amount,discount,eligiblePromo};
}

export async function quoteHandler(request,db,now=Date.now()){
  if(!db)return Response.json({error:'Сервер аккаунтов не настроен'},{status:503});
  const url=new URL(request.url);
  if(request.method!=='POST'||request.headers.get('origin')!==url.origin)return Response.json({error:'Недопустимый запрос'},{status:403});
  const session=(request.headers.get('cookie')||'').match(/(?:^|;\s*)auradon_cloud_session=([a-f0-9]{64})(?:;|$)/)?.[1];
  if(!session)return Response.json({error:'Войдите в аккаунт'},{status:401});
  const user=await db.prepare('SELECT user_id FROM sessions WHERE token_hash = ? AND expires_at > ?').bind(hash(session),now).first();
  if(!user)return Response.json({error:'Войдите в аккаунт'},{status:401});
  try{const text=await request.text();if(text.length>2048)throw Error('Запрос слишком большой');return Response.json({quote:calculateQuote(JSON.parse(text))},{headers:{'Cache-Control':'no-store'}});}catch(e){return Response.json({error:e instanceof SyntaxError?'Неверный запрос':e.message},{status:400,headers:{'Cache-Control':'no-store'}});}
}
