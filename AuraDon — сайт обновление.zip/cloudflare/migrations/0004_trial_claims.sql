CREATE TABLE IF NOT EXISTS trial_claims (user_id TEXT PRIMARY KEY, claimed_at INTEGER NOT NULL);
INSERT OR IGNORE INTO trial_claims (user_id,claimed_at) SELECT user_id,trial_end-604800000 FROM entitlements WHERE trial_end>0;
