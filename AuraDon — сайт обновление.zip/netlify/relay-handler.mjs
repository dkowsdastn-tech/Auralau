import{createHash,timingSafeEqual}from'node:crypto';
const hash=v=>createHash('sha256').update(v).digest('hex');
export async function relayHandler(req,store){
 const u=new URL(req.url),token=u.searchParams.get('access')||'',media=u.searchParams.get('media');
 const response=(body,status=200,extra={})=>new Response(body,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...extra}});
 if(!/^[a-f\d]{64}$/.test(token))return response('Invalid link',404);
 if(media&&!/^[a-f\d-]+\.(gif|png|jpg|webp|mp4|webm|mp3|wav|ogg)$/.test(media))return response('Invalid media',400);
 if(req.method==='PUT'){
  const secret=(req.headers.get('authorization')||'').replace(/^Bearer /,'');const actual=hash(secret);if(secret.length!==64||!timingSafeEqual(Buffer.from(actual),Buffer.from(token)))return response('Forbidden',403);
  const body=await req.arrayBuffer();if(body.byteLength>2*1024*1024)return response('Too large',413);
  if(media){const part=Number(u.searchParams.get('part')),total=Number(u.searchParams.get('total'));if(!Number.isInteger(part)||!Number.isInteger(total)||part<0||total<1||total>40||part>=total||body.byteLength>524288)return response('Invalid chunk',400);const type=u.searchParams.get('type');if(!['image/gif','image/png','image/jpeg','image/webp','video/mp4','video/webm','audio/mpeg','audio/wav','audio/ogg','audio/x-wav'].includes(type))return response('Invalid type',400);await store.set(token+'/'+media+'/'+part,body);if(part===total-1)await store.setJSON(token+'/'+media+'/meta',{total,type});}
  else{let packet;try{packet=JSON.parse(new TextDecoder().decode(body));}catch{return response('Invalid JSON',400);}if(!Array.isArray(packet.deliveries)||!Number.isFinite(packet.updatedAt)||packet.state!==null&&(!packet.state?.settings||!Array.isArray(packet.state?.events)))return response('Invalid state',400);await store.setJSON(token+'/state',packet);}
  return response('{}',200,{'Content-Type':'application/json'});
 }
 if(req.method!=='GET')return response('Method not allowed',405);
 if(media){const active=await store.get(token+'/state',{type:'json'});if(!active?.state)return response('Not found',404);const meta=await store.get(token+'/'+media+'/meta',{type:'json'});if(!meta)return response('Not found',404);let part=0;const stream=new ReadableStream({async pull(controller){if(part>=meta.total){controller.close();return;}const chunk=await store.get(token+'/'+media+'/'+part++,{type:'arrayBuffer'});if(!chunk){controller.error(Error('Missing chunk'));return;}controller.enqueue(new Uint8Array(chunk));}});return response(stream,200,{'Content-Type':meta.type});}
 const packet=await store.get(token+'/state',{type:'json'});if(!packet?.state)return response('Overlay not connected',404);
 const since=Number(u.searchParams.get('since'))||0,etag='"'+hash(JSON.stringify(packet)+since)+'"';if(req.headers.get('if-none-match')===etag)return response(null,304,{ETag:etag});return response(JSON.stringify({...packet,deliveries:packet.deliveries.filter(p=>p.seq>since)}),200,{'Content-Type':'application/json',ETag:etag});
}
