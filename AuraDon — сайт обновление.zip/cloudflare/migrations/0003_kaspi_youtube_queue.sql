ALTER TABLE video_stream_settings ADD COLUMN min_amount INTEGER NOT NULL DEFAULT 500 CHECK(min_amount BETWEEN 100 AND 10000000);
ALTER TABLE video_stream_settings ADD COLUMN max_seconds INTEGER NOT NULL DEFAULT 180 CHECK(max_seconds BETWEEN 15 AND 600);
ALTER TABLE video_stream_settings ADD COLUMN position TEXT NOT NULL DEFAULT 'right' CHECK(position IN ('left','right'));
ALTER TABLE video_stream_settings ADD COLUMN widget_width INTEGER NOT NULL DEFAULT 420 CHECK(widget_width IN (320,420,520));
ALTER TABLE video_requests ADD COLUMN donation_amount REAL;
ALTER TABLE video_requests ADD COLUMN donation_event_id TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS video_requests_donation_event ON video_requests(donation_event_id) WHERE donation_event_id IS NOT NULL;
