// The order determines which presets are available on each plan.
export const TOP_STYLES=[
  ['broadcast','Эфир · золото','#ffd12b'],['lime','Лайм','#ccff35'],
  ['ember','Уголь','#ffa149'],['ice','Лёд','#70dbff'],['rose','Розовый свет','#ff83be'],['chrome','Хром','#d0e1ee'],['mono','Моно','#ffffff'],['goldline','Золотая линия','#ffd12b'],
  ['rainbow','Радуга','#e888fa'],['neon','Неон','#a888ff'],['medals','Медали','#f5c74f'],['glass','Стекло','#d1c6f7'],['classic','Классика','#f5c74f'],['tiktok','Live Beat','#ff5793'],['bubble','Bubble','#ff9ac9'],['cosmic','Cosmic','#9b7cff'],['podium','Пьедестал','#efc54b'],['arena','Арена','#ff6c48'],['royal','Королевский','#d7b8ff'],['comet','Комета','#5ce1ff'],
  ['ultraviolet','Ультрафиолет','#c58cff'],['cherry','Вишня','#ff6e92'],['ocean','Океан','#45d8e2'],['emerald','Изумруд','#63e4ab'],['candy','Карамель','#ffb5da'],['hologram','Голограмма','#9de9ff'],['eclipse','Затмение','#d6a6ff'],['sunsetglow','Закат','#ffad79'],['retro','Ретро','#f8cf70'],['crystal','Кристалл','#c9ecff'],
  ['flare','Солнечная вспышка','#ffc04f'],['arctic','Полярное сияние','#68f9db'],['pulse','Пульс','#ff5997'],['royalblue','Сапфир','#7bbdff'],['obsidian','Обсидиан','#edc784'],['aurora','Северное сияние','#a8f0ff']
].map(([id,label,accent],index)=>({id,label,accent,tier:index<1?'free':index<20?'pro':'ultimate'}));
