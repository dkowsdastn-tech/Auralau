import{getStore}from'@netlify/blobs';import{speechHandler}from'../speech-handler.mjs';export default req=>speechHandler(req,getStore({name:'auradon-overlays-v1',consistency:'strong'}));
